var e = require("../../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isFunction = r, exports.isPlainObject = n, exports.isPromise = function(e) {
    return n(e) && r(e.then) && r(e.catch);
}, exports.isDef = function(e) {
    return null != e;
}, exports.isObj = function(e) {
    var r = (0, t.default)(e);
    return null !== e && ("object" === r || "function" === r);
}, exports.isNumber = function(e) {
    return /^\d+(\.\d+)?$/.test(e);
}, exports.isBoolean = function(e) {
    return "boolean" == typeof e;
}, exports.isImageUrl = function(e) {
    return i.test(e);
}, exports.isVideoUrl = function(e) {
    return o.test(e);
};

var t = e(require("../../../@babel/runtime/helpers/typeof"));

function r(e) {
    return "function" == typeof e;
}

function n(e) {
    return null !== e && "object" === (0, t.default)(e) && !Array.isArray(e);
}

var i = /\.(jpeg|jpg|gif|png|svg|webp|jfif|bmp|dpg)/i, o = /\.(mp4|mpg|mpeg|dat|asf|avi|rm|rmvb|mov|wmv|flv|mkv)/i;