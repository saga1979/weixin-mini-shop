var e, t = require("../../@babel/runtime/helpers/interopRequireDefault"), n = t(require("../../@babel/runtime/regenerator")), a = t(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        displayItems: [],
        address: {},
        orderNO: ""
    },
    onLoad: (e = (0, a.default)(n.default.mark(function e(t) {
        var a;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                console.debug(t), a = this, this.setData({
                    address: JSON.parse(t.address)
                }), this.getOpenerEventChannel().on("acceptDataFromOrder", function(e) {
                    console.log(e), a.data.displayItems = e.list, a.setData({
                        displayItems: a.data.displayItems,
                        order: e
                    });
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onReady: function() {
        console.debug("ready");
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onSelectAddress: function(e) {
        var t = this;
        wx.navigateTo({
            url: "../address/address?readonly=true",
            events: {
                addressSelected: function(e) {
                    console.debug("selected address:", e), t.setData({
                        address: e
                    });
                }
            }
        });
    },
    onSubmit: function() {
        var e = !0, t = new Date();
        console.debug("minutes:", t.getMinutes() % 2), t.getMinutes() % 2 == 0 && (e = !1);
        var n = Date.now().toString(16) + Math.random().toString(16), a = [ n.substr(8, 4), n.substr(16, 12) ].join("-");
        this.getOpenerEventChannel().emit("submitOrder", {
            NO: a,
            payed: e,
            address: this.data.address,
            time: new Date()
        }), wx.navigateBack({
            delta: 0
        });
    }
});