function o() {}

module.exports.getGoodsInfos = o, exports.getGoodsInfos = o;