var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), t = require("../common/component"), n = require("../mixins/button"), o = require("../mixins/open-type"), i = require("../common/color");

(0, t.VantComponent)({
    mixins: [ n.button, o.openType ],
    props: {
        show: {
            type: Boolean,
            observer: function(e) {
                !e && this.stopLoading();
            }
        },
        title: String,
        message: String,
        theme: {
            type: String,
            value: "default"
        },
        useSlot: Boolean,
        className: String,
        customStyle: String,
        asyncClose: Boolean,
        messageAlign: String,
        overlayStyle: String,
        useTitleSlot: Boolean,
        showCancelButton: Boolean,
        closeOnClickOverlay: Boolean,
        confirmButtonOpenType: String,
        width: null,
        zIndex: {
            type: Number,
            value: 2e3
        },
        confirmButtonText: {
            type: String,
            value: "确认"
        },
        cancelButtonText: {
            type: String,
            value: "取消"
        },
        confirmButtonColor: {
            type: String,
            value: i.RED
        },
        cancelButtonColor: {
            type: String,
            value: i.GRAY
        },
        showConfirmButton: {
            type: Boolean,
            value: !0
        },
        overlay: {
            type: Boolean,
            value: !0
        },
        transition: {
            type: String,
            value: "scale"
        }
    },
    data: {
        loading: {
            confirm: !1,
            cancel: !1
        }
    },
    methods: {
        onConfirm: function() {
            this.handleAction("confirm");
        },
        onCancel: function() {
            this.handleAction("cancel");
        },
        onClickOverlay: function() {
            this.onClose("overlay");
        },
        handleAction: function(t) {
            this.data.asyncClose && this.setData((0, e.default)({}, "loading.".concat(t), !0)), 
            this.onClose(t);
        },
        close: function() {
            this.setData({
                show: !1
            });
        },
        stopLoading: function() {
            this.setData({
                loading: {
                    confirm: !1,
                    cancel: !1
                }
            });
        },
        onClose: function(e) {
            this.data.asyncClose || this.close(), this.$emit("close", e), this.$emit(e, {
                dialog: this
            });
            var t = this.data["confirm" === e ? "onConfirm" : "onCancel"];
            t && t(this);
        }
    }
});