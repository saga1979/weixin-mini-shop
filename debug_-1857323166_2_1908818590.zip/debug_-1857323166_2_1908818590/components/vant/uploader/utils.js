Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isImageFile = function(e) {
    if (null != e.isImage) return e.isImage;
    if (e.type) return "image" === e.type;
    if (e.url) return (0, t.isImageUrl)(e.url);
    return !1;
}, exports.isVideoFile = function(e) {
    if (null != e.isVideo) return e.isVideo;
    if (e.type) return "video" === e.type;
    if (e.url) return (0, t.isVideoUrl)(e.url);
    return !1;
}, exports.chooseFile = function(t) {
    var i = t.accept, r = t.multiple, u = t.capture, n = t.compressed, s = t.maxDuration, a = t.sizeType, c = t.camera, o = t.maxCount;
    return new Promise(function(t, p) {
        switch (i) {
          case "image":
            wx.chooseImage({
                count: r ? Math.min(o, 9) : 1,
                sourceType: u,
                sizeType: a,
                success: function(i) {
                    return t(function(t) {
                        return t.tempFiles.map(function(t) {
                            return Object.assign(Object.assign({}, (0, e.pickExclude)(t, [ "path" ])), {
                                type: "image",
                                url: t.path,
                                thumb: t.path
                            });
                        });
                    }(i));
                },
                fail: p
            });
            break;

          case "media":
            wx.chooseMedia({
                count: r ? Math.min(o, 9) : 1,
                sourceType: u,
                maxDuration: s,
                sizeType: a,
                camera: c,
                success: function(i) {
                    return t(function(t) {
                        return t.tempFiles.map(function(i) {
                            return Object.assign(Object.assign({}, (0, e.pickExclude)(i, [ "fileType", "thumbTempFilePath", "tempFilePath" ])), {
                                type: t.type,
                                url: i.tempFilePath,
                                thumb: "video" === t.type ? i.thumbTempFilePath : i.tempFilePath
                            });
                        });
                    }(i));
                },
                fail: p
            });
            break;

          case "video":
            wx.chooseVideo({
                sourceType: u,
                compressed: n,
                maxDuration: s,
                camera: c,
                success: function(i) {
                    return t(function(t) {
                        return [ Object.assign(Object.assign({}, (0, e.pickExclude)(t, [ "tempFilePath", "thumbTempFilePath", "errMsg" ])), {
                            type: "video",
                            url: t.tempFilePath,
                            thumb: t.thumbTempFilePath
                        }) ];
                    }(i));
                },
                fail: p
            });
            break;

          default:
            wx.chooseMessageFile({
                count: r ? o : 1,
                type: i,
                success: function(i) {
                    return t(function(t) {
                        return t.tempFiles.map(function(t) {
                            return Object.assign(Object.assign({}, (0, e.pickExclude)(t, [ "path" ])), {
                                url: t.path
                            });
                        });
                    }(i));
                },
                fail: p
            });
        }
    });
};

var e = require("../common/utils"), t = require("../common/validator");