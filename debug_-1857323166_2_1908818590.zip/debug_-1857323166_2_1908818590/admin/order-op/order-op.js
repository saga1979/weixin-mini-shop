var e, t, a = require("../../@babel/runtime/helpers/interopRequireDefault"), n = a(require("../../@babel/runtime/regenerator")), r = a(require("../../@babel/runtime/helpers/asyncToGenerator")), o = (getApp(), 
require("miniprogram-recycle-view")), i = function(e) {
    return e / 750 * wx.getSystemInfoSync().windowWidth;
}, s = null;

Page({
    data: {
        nickName: "",
        avatarUrl: "",
        _openid: "",
        _stages: [],
        _ordersToShow: []
    },
    onLoad: function(e) {
        console.debug(e), this.data._stages = JSON.parse("[" + e.value + "]"), this.data._openid = e.openid, 
        this.getOrderInfos(this.data._stages, {
            begin: 1,
            end: 100
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    getOrderInfos: (t = (0, r.default)(n.default.mark(function e(t, a) {
        var r, i, d, u;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r = this, e.next = 3, wx.cloud.callFunction({
                    name: "orders-op",
                    data: {
                        cmd: "get",
                        stages: t,
                        range: {
                            begin: a.begin,
                            end: a.end
                        },
                        openid: this.data._openid
                    }
                });

              case 3:
                for (i = e.sent, console.debug(i.result), r.data._ordersToShow = [], d = 0; d < i.result.data.length; d++) u = i.result.data[d], 
                r.data._ordersToShow.push(u);
                r.setData({
                    _ordersToShow: i.result.data
                }), (s = o({
                    id: "recycleId",
                    dataKey: "recycleList",
                    page: this,
                    itemSize: this.itemSizeFunc,
                    useInPage: !1
                })).splice(0, s.getList().length), s.append(r.data._ordersToShow), console.debug(r.data._ordersToShow);

              case 12:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e, a) {
        return t.apply(this, arguments);
    }),
    itemSizeFunc: function(e, t) {
        return {
            width: i(750),
            height: i(350)
        };
    },
    onOrderConfirm: (e = (0, r.default)(n.default.mark(function e(t) {
        var a, r, o;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (console.debug(t), -1 != (a = this.data._ordersToShow.findIndex(function(e) {
                    return e._id == t.target.dataset.id;
                }))) {
                    e.next = 4;
                    break;
                }
                return e.abrupt("return");

              case 4:
                return this.data._ordersToShow[a].stage.value = 2, this.data._ordersToShow[a].stage.title = "已确认", 
                r = {
                    openid: this.data._openid,
                    status: "系统已确认",
                    time: new Date()
                }, this.data._ordersToShow[a].timeline.push(r), s.update(a, [ this.data._ordersToShow[a] ]), 
                e.next = 11, wx.cloud.callFunction({
                    name: "orders-op",
                    data: {
                        cmd: "update-stage",
                        data: {
                            id: t.target.dataset.id,
                            stage: this.data._ordersToShow[a].stage,
                            timeline: r
                        }
                    }
                });

              case 11:
                o = e.sent, console.debug(o);

              case 13:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    })
});