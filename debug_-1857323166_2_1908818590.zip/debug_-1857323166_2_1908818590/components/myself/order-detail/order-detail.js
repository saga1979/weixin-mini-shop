var e, n = require("../../../@babel/runtime/helpers/interopRequireDefault"), t = n(require("../../../@babel/runtime/regenerator")), o = n(require("../../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        orderInfo: {},
        _id: ""
    },
    onLoad: function(e) {
        console.debug(e), this.data._id = e.id;
    },
    onReady: function() {
        console.debug("onready");
    },
    onShow: (e = (0, o.default)(t.default.mark(function e() {
        var n;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.debug("onshow", this.data._id), e.next = 3, wx.cloud.callFunction({
                    name: "orders-op",
                    data: {
                        cmd: "get-byIDs",
                        data: [ this.data._id ]
                    }
                });

              case 3:
                n = e.sent, console.debug(n), this.setData({
                    orderInfo: n.result.data[0]
                });

              case 6:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return e.apply(this, arguments);
    }),
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});