var o, t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), n = t(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        _old: []
    },
    onLoad: (o = (0, n.default)(e.default.mark(function o(t) {
        var n, a;
        return e.default.wrap(function(o) {
            for (;;) switch (o.prev = o.next) {
              case 0:
                return wx.showLoading({
                    title: "正在加载数据"
                }), o.next = 3, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get-all"
                    }
                });

              case 3:
                for (n = o.sent, wx.hideLoading({
                    success: function(o) {}
                }), n.result.success || wx.showToast({
                    title: "数据为空"
                }), this.setData({
                    goodsInfos: n.result.data
                }), a = 0; a < this.data.goodsInfos.length; a++) this.data._old.push(this.data.goodsInfos[a].recommend);

              case 8:
              case "end":
                return o.stop();
            }
        }, o, this);
    })), function(t) {
        return o.apply(this, arguments);
    }),
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        for (var o = [], t = [], e = 0; e < this.data.goodsInfos.length; e++) this.data.goodsInfos[e].recommend != this.data._old[e] && (this.data._old[e] ? t.push(this.data.goodsInfos[e]._id) : o.push(this.data.goodsInfos[e]._id));
        0 == o.length && 0 == t.length || (console.debug("onList:", o), console.debug("offList:", t), 
        wx.cloud.callFunction({
            name: "goods-op",
            data: {
                cmd: "update-recommend",
                onList: o,
                offList: t
            }
        }).then(function(o) {
            console.debug(o);
        }).catch(function(o) {
            console.error(o);
        }));
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    goodsOnorOff: function(o) {
        console.debug(o), this.data.goodsInfos[o.target.dataset.index].recommend = o.detail.value;
    }
});