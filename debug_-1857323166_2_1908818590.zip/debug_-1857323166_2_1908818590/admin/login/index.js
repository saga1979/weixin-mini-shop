var e, t, n, r, a, s = require("../../@babel/runtime/helpers/interopRequireDefault"), i = s(require("../../@babel/runtime/regenerator")), u = s(require("../../@babel/runtime/helpers/asyncToGenerator")), o = (require("../../libs/runtime"), 
getApp());

Page({
    db: null,
    data: {
        title: "user",
        isAuthorized: !1,
        userInfo: o.globalData.userInfo,
        zf: 111
    },
    onLoad: (a = (0, u.default)(i.default.mark(function e() {
        return i.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                this.db = wx.cloud.database(), this.checkAuthSetting(), this.checkUser();

              case 3:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return a.apply(this, arguments);
    }),
    checkAuthSetting: function() {
        var e = this;
        wx.getSetting({
            success: function(t) {
                var n;
                t.authSetting["scope.userInfo"] ? wx.getUserInfo({
                    success: (n = (0, u.default)(i.default.mark(function t(n) {
                        var r, a;
                        return i.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                n.userInfo && (r = n.userInfo, e.setUserTemp(r)), (a = e.data.userInfo || {}).isLoaded = !0, 
                                e.setData({
                                    userInfo: a,
                                    isAuthorized: !0
                                });

                              case 4:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    })), function(e) {
                        return n.apply(this, arguments);
                    })
                }) : e.setData({
                    userInfo: {
                        isLoaded: !0
                    }
                });
            }
        });
    },
    checkUser: (r = (0, u.default)(i.default.mark(function e() {
        var t, n, r = this;
        return i.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t = this.db.collection("users"), e.next = 3, t.get();

              case 3:
                n = e.sent, wx.checkSession({
                    success: function() {
                        n.data.length && r.checkSession(n.data[0].expireTime || 0) ? r.setUserInfo(n.data[0]) : (r.setUserInfo(), 
                        r.updateSession());
                    },
                    fail: function() {
                        r.updateSession();
                    }
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return r.apply(this, arguments);
    }),
    updateSession: function() {
        var e;
        wx.login({
            success: (e = (0, u.default)(i.default.mark(function e(t) {
                return i.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, wx.cloud.callFunction({
                            name: "user-session",
                            data: {
                                code: t.code
                            }
                        });

                      case 3:
                        e.next = 7;
                        break;

                      case 5:
                        e.prev = 5, e.t0 = e.catch(0);

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 0, 5 ] ]);
            })), function(t) {
                return e.apply(this, arguments);
            })
        });
    },
    checkSession: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        return !(Date.now() > e);
    },
    setUserInfo: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
        e.isLoaded = !0, Object.prototype.hasOwnProperty.call(e, "session_key") && delete e.session_key, 
        o.globalData.userInfo = e, this.setData({
            userInfo: e
        }, t);
    },
    setUserTemp: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : function() {};
        this.setData({
            userTemp: e,
            isAuthorized: t
        }, n);
    },
    bindGetUserInfoNew: (n = (0, u.default)(i.default.mark(function e(t) {
        var n;
        return i.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                n = t.detail.userInfo, this.setUserTemp(n);

              case 2:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return n.apply(this, arguments);
    }),
    bindGetPhoneNumber: (t = (0, u.default)(i.default.mark(function e(t) {
        var n, r;
        return i.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return wx.showLoading({
                    title: "正在获取"
                }), this.data.zf = t, e.prev = 2, n = this.data.userTemp, e.next = 6, wx.cloud.callFunction({
                    name: "user-login-register",
                    data: {
                        encryptedData: t.detail.encryptedData,
                        iv: t.detail.iv,
                        user: {
                            nickName: n.nickName,
                            avatarUrl: n.avatarUrl,
                            gender: n.gender
                        }
                    }
                });

              case 6:
                !(r = e.sent).result.code && r.result.data && this.setUserInfo(r.result.data), wx.hideLoading(), 
                e.next = 15;
                break;

              case 11:
                e.prev = 11, e.t0 = e.catch(2), wx.hideLoading(), wx.showToast({
                    title: "获取手机号码失败，请重试",
                    icon: "none"
                });

              case 15:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 2, 11 ] ]);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    bindLogout: (e = (0, u.default)(i.default.mark(function e() {
        var t;
        return i.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t = this.data.userInfo, e.next = 3, this.db.collection("users").doc(t._id).update({
                    data: {
                        expireTime: 0
                    }
                });

              case 3:
                this.setUserInfo();

              case 4:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return e.apply(this, arguments);
    })
});