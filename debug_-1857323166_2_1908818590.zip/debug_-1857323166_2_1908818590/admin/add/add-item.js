var e, t, a = require("../../@babel/runtime/helpers/interopRequireDefault"), s = a(require("../../@babel/runtime/regenerator")), o = a(require("../../@babel/runtime/helpers/asyncToGenerator"));

getApp();

Page({
    data: {
        goods_name: "",
        goods_des: "",
        goodsTypes: [],
        imageUrls: [],
        units: [ "斤", "箱", "个", "只", "件" ],
        unitIndex: 0,
        goods_unit: "",
        goods_price: 10,
        goods_imgs_id: [],
        isPreviewing: !1,
        previewImageUrls: [],
        min_date: new Date().toISOString().substring(0, 10),
        max_date: "2021-03-07",
        added: !1,
        goodsItems: [],
        goodsType: 0,
        recommend: !0
    },
    onLoad: (t = (0, o.default)(s.default.mark(function e(t) {
        var a, o, n;
        return s.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = new Date(), this.setData({
                    goods_date: a.toISOString().substring(0, 10)
                }), e.next = 4, wx.cloud.callFunction({
                    name: "config",
                    data: {
                        cmd: "goodsTypes-get"
                    }
                });

              case 4:
                o = e.sent, console.debug(o.result.data), n = [], o.result.data.forEach(function(e) {
                    n.push(e.title);
                }), this.setData({
                    goodsTypes: n
                });

              case 9:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.getOpenerEventChannel().emit("goodsAdded", {
            num: this.data.goodsItems.length,
            items: this.data.goodsItems
        }), console.debug(this.data.goodsItems);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onUpdateItem: (e = (0, o.default)(s.default.mark(function e(t) {
        var a, n, i, d, r, l = this;
        return s.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (0 != this.data.imageUrls.length) {
                    e.next = 3;
                    break;
                }
                return wx.showModal({
                    title: "必须设置图片"
                }), e.abrupt("return");

              case 3:
                for (r in a = !1, n = this, this.data.goods_imgs_id = [], i = 0, d = function() {
                    wx.showLoading({
                        title: "上传图片".concat(r, "/").concat(l.data.imageUrls.length)
                    });
                    var e, t = l.data.imageUrls[r].path, d = l.data.imageUrls[r].file;
                    wx.cloud.uploadFile({
                        cloudPath: t,
                        filePath: d,
                        success: function(e) {
                            n.data.goods_imgs_id.push(e.fileID), i++, console.log("[上传文件] success：index=", r, t);
                        },
                        fail: function(e) {
                            console.error("[上传文件] fail：", e, t, d), i++;
                        },
                        complete: (e = (0, o.default)(s.default.mark(function e(t) {
                            var o;
                            return s.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (console.debug("[文件完成]:", r + 1), i != n.data.imageUrls.length) {
                                        e.next = 11;
                                        break;
                                    }
                                    return console.log("写数据库的队列:", r + 1), wx.hideLoading(), wx.showLoading({
                                        title: "正在写入数据库"
                                    }), console.debug(n.data.goods_date), o = new Date(n.data.goods_date + " 23:59:59"), 
                                    e.next = 9, wx.cloud.callFunction({
                                        name: "goods-op",
                                        data: {
                                            cmd: "set",
                                            data: {
                                                name: n.data.goods_name,
                                                des: n.data.goods_des,
                                                imgs: n.data.goods_imgs_id,
                                                unit: n.data.units[n.data.unitIndex],
                                                price: n.data.goods_price,
                                                date: o,
                                                isSelling: !0,
                                                type: n.data.goodsTypes[n.data.goodsType],
                                                recommend: n.data.recommend
                                            }
                                        }
                                    }).then(function(e) {
                                        if (console.debug(e), e.result.success) {
                                            a = !0;
                                            var t = {
                                                _id: e.result.data,
                                                date: o,
                                                des: n.data.goods_des,
                                                imgs: n.data.goods_imgs_id,
                                                isSelling: !0,
                                                name: n.data.goods_name,
                                                price: n.data.goods_price,
                                                unit: n.data.units[n.data.unitIndex]
                                            };
                                            n.data.goodsItems.push(t), n.setData({
                                                goods_name: "",
                                                goods_des: "",
                                                imageUrls: [],
                                                goods_imgs_id: [],
                                                isPreviewing: !1,
                                                previewImageUrls: []
                                            });
                                        }
                                    }).catch(function(e) {
                                        console.log(e);
                                    });

                                  case 9:
                                    wx.hideLoading(), a || wx.showToast({
                                        title: "未能成功添加信息",
                                        icon: "none"
                                    });

                                  case 11:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        })), function(t) {
                            return e.apply(this, arguments);
                        })
                    });
                }, this.data.imageUrls) d();

              case 9:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onSelectImg: function() {
        var e = this;
        wx.chooseImage({
            count: 9,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                for (var a = Date.now().toString(16) + Math.random().toString(16) + "0".repeat(16), s = ([ a.substr(0, 8), a.substr(8, 4), "4000-8" + a.substr(13, 3), a.substr(16, 12) ].join("-"), 
                Date.now()), o = 0; o < t.tempFilePaths.length; o++) {
                    var n = "goods/" + s + "[" + o + "]" + t.tempFilePaths[o].match(/\.[^.]+?$/)[0];
                    console.log(n);
                    var i = e.data.imageUrls;
                    e.data.imageUrls.push({
                        path: n,
                        file: t.tempFilePaths[o]
                    }), e.data.previewImageUrls.push(t.tempFilePaths[o]), e.setData({
                        imageUrls: i
                    });
                }
            },
            fail: function(e) {
                console.error(e);
            }
        });
    },
    bindDateChange: function(e) {
        this.setData({
            goods_date: e.detail.value
        });
    },
    bindUnitChange: function(e) {
        this.setData({
            unitIndex: e.detail.value
        });
    },
    onPreviewImage: function(e) {
        console.log(e), this.setData({
            isPreviewing: !0,
            previewCurrent: e.currentTarget.dataset.index,
            previewImageUrls: this.data.previewImageUrls
        });
    },
    onDeletePic: function(e) {
        console.log(e), this.setData({
            imageUrls: this.data.imageUrls.splice(e.detail.index, 1),
            previewImageUrls: this.data.previewImageUrls.splice(e.detail.index, 1)
        });
    }
});