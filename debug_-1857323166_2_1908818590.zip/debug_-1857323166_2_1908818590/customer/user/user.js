Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        openid: String
    },
    data: {},
    lifetimes: {
        ready: function() {
            console.debug(this.data);
        }
    }
});