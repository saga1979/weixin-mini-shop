var t, e, n, a = require("../../@babel/runtime/helpers/interopRequireDefault"), o = a(require("../../@babel/runtime/regenerator")), i = a(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        goodsInfos: [],
        viewHeight: 1e3,
        _goodsIDs: []
    },
    onLoad: (n = (0, i.default)(o.default.mark(function t(e) {
        var n, a, i, s, d, u, r;
        return o.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (console.debug("option:", e), null == e._id) {
                    t.next = 11;
                    break;
                }
                return this.setData({
                    _id: e._id
                }), n = this, t.next = 6, wx.cloud.callFunction({
                    name: "discount",
                    data: {
                        cmd: "get",
                        where: {
                            _id: e._id
                        }
                    }
                });

              case 6:
                a = t.sent, console.debug(a), a.result.success && (i = a.result.data[0], s = new Date(i.start), 
                d = new Date(i.end), i.start = s, i.end = d, n.setData({
                    title: i.title,
                    total: i.total,
                    cut: i.cut,
                    startDate: s.getFullYear() + "-" + (s.getMonth() + 1) + "-" + s.getDate(),
                    startTime: s.getHours() + ":" + s.getMinutes(),
                    endDate: d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(),
                    endTime: d.getHours() + ":" + d.getMinutes(),
                    _oldInfo: i
                })), t.next = 12;
                break;

              case 11:
                null != e.type && (this.data._type = e.type);

              case 12:
                return wx.showLoading({
                    title: "正在加载资源"
                }), t.next = 15, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get"
                    }
                });

              case 15:
                a = t.sent, u = a.result.data, null != e._id && (r = this, u.forEach(function(t) {
                    -1 != r.data._oldInfo.goods.findIndex(function(e) {
                        return e == t._id;
                    }) && (t.checked = !0);
                })), this.setData({
                    goodsInfos: u
                }), wx.hideLoading({
                    complete: function(t) {}
                });

              case 20:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function(t) {
        return n.apply(this, arguments);
    }),
    onReady: (e = (0, i.default)(o.default.mark(function t() {
        var e;
        return o.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                e = wx.getSystemInfoSync().windowHeight, null != this.data._type ? this.setData({
                    viewHeight: e,
                    startDate: new Date().toISOString().substring(0, 10),
                    startTime: "00:00",
                    endDate: new Date().toISOString().substring(0, 10),
                    endTime: "23:59"
                }) : this.setData({
                    viewHeight: e
                }), console.debug(this.data.startDate);

              case 3:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return e.apply(this, arguments);
    }),
    onShow: function() {},
    onHide: function() {},
    onUnload: (t = (0, i.default)(o.default.mark(function t() {
        var e, n, a, i, s, d, u;
        return o.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                (e = {}).title = this.data.title, e.total = Number(this.data.total), e.cut = Number(this.data.cut), 
                e.start = new Date(this.data.startDate + " " + this.data.startTime), e.end = new Date(this.data.endDate + " " + this.data.endTime), 
                n = [], this.data.goodsInfos.forEach(function(t) {
                    t.checked && n.push(t._id);
                }), e.goods = n, e.type = null != this.data._type ? this.data._type : this.data._oldInfo.type, 
                console.debug("discount:", e), a = this.getOpenerEventChannel(), null != this.data._oldInfo ? (i = this.data._oldInfo, 
                s = {}, d = Object.keys(e), console.debug("keys:", d), d.forEach(function(t) {
                    console.debug(t + ":", i[t], e[t]), i[t] != e[t] && (s[t] = e[t]);
                }), null != s.start && i.start.getTime() == e.start.getTime() && delete s.start, 
                null != s.end && i.end.getTime() == e.end.getTime() && delete s.end, null != s.goods && i.goods.length == e.goods.length && (u = !1, 
                s.goods.forEach(function(t) {
                    -1 == e.goods.findIndex(function(e) {
                        return e == t;
                    }) && (u = !0);
                }), u || delete s.goods), 0 != Object.keys(s).length && (console.debug("emit update!"), 
                a.emit("update", {
                    id: i._id,
                    update: s
                }))) : null != e.title && null != e.total && null != e.cut && a.emit("add", e);

              case 13:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return t.apply(this, arguments);
    }),
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    titleChange: function(t) {},
    totalChange: function(t) {},
    cutChange: function(t) {},
    bindStartDateChange: function(t) {},
    bindStartTimeChange: function(t) {},
    bindEndDateChange: function(t) {},
    bindEndTimeChange: function(t) {},
    goodsOnorOff: function(t) {
        console.debug(t), this.data.goodsInfos[t.target.dataset.index].checked = t.detail.value;
    }
});