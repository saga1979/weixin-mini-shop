var e, t, o, n, a = require("../../@babel/runtime/helpers/interopRequireDefault"), s = a(require("../../@babel/runtime/helpers/defineProperty")), d = a(require("../../@babel/runtime/regenerator")), i = a(require("../../@babel/runtime/helpers/asyncToGenerator"));

getApp();

Page((e = {
    data: {
        avatarUrl: "./user-unlogin.png",
        userInfo: {},
        logged: !1,
        takeSession: !1,
        requestResult: "",
        list: [ {
            text: "我",
            iconPath: "/images/customer_user_home.png",
            selectedIconPath: "/images/selected_common.png"
        }, {
            text: "订单",
            iconPath: "/images/customer_user_cart.png",
            selectedIconPath: "/images/selected_common.png"
        }, {
            text: "商品",
            iconPath: "/images/customer_user_history.png",
            selectedIconPath: "/images/selected_common.png"
        }, {
            text: "管理",
            iconPath: "/images/customer_user_history.png",
            selectedIconPath: "/images/selected_common.png"
        } ],
        pageIndex: 0,
        goods_items: []
    },
    onLoad: (n = (0, i.default)(d.default.mark(function e(t) {
        var o, n, a, s = this;
        return d.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.debug(t), this.setData({
                    _openid: t.openid
                }), wx.getSetting({
                    success: function(e) {
                        e.authSetting["scope.userInfo"] && wx.getUserInfo({
                            success: function(e) {
                                s.setData({
                                    avatarUrl: e.userInfo.avatarUrl,
                                    userInfo: e.userInfo
                                });
                            }
                        });
                    }
                }), o = wx.getSystemInfoSync(), this.data.viewRegionHight = o.screenHeight - 200, 
                n = this, this.data._db = wx.cloud.database(), this.data._watcher = this.data._db.collection("configs").where({
                    openid: this.data._openid
                }).watch({
                    onChange: function(e) {
                        if (console.log("docs's changed events", e.docChanges), console.log("query result snapshot after the event", e.docs), 
                        console.log("is init data", "init" === e.type), null != e.docChanges[0].updatedFields && null != e.docChanges[0].updatedFields.goodsTypes) {
                            var t = [];
                            e.docChanges[0].updatedFields.goodsTypes.forEach(function(e) {
                                t.push(e.title);
                            }), n.data._goodsTypes = t;
                        }
                    },
                    onError: function(e) {
                        console.error("db watcher:", e);
                    }
                }), e.next = 10, wx.cloud.callFunction({
                    name: "config",
                    data: {
                        cmd: "goodsTypes-get"
                    }
                });

              case 10:
                a = e.sent, wx.hideLoading({
                    success: function(e) {}
                }), console.debug(a.result.data), this.data._goodsTypes = [], a.result.data.forEach(function(e) {
                    s.data._goodsTypes.push(e.title);
                });

              case 15:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return n.apply(this, arguments);
    }),
    onShow: function() {},
    onReady: function() {
        var e = wx.createSelectorQuery();
        e.select("#admin-index-tabber").boundingClientRect();
        var t = this;
        e.exec(function(e) {
            var o = wx.getSystemInfoSync().windowHeight - e[0].height;
            console.debug("new height:", o), t.data.viewHight != o && t.setData({
                viewHight: o
            });
        });
    },
    onGetUserInfo: function(e) {
        !this.data.logged && e.detail.userInfo && this.setData({
            logged: !0,
            avatarUrl: e.detail.userInfo.avatarUrl,
            userInfo: e.detail.userInfo
        });
    },
    onGetGoods: (o = (0, i.default)(d.default.mark(function e() {
        var t, o, n;
        return d.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return wx.showLoading({
                    title: "正在加载资源"
                }), e.next = 3, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get"
                    }
                });

              case 3:
                for (t = e.sent, o = t.result.data, n = 0; n < o.length; n++) o[n].buttons = [ {
                    text: "删除",
                    src: "../../../images/trash.png",
                    data: o[n]._id
                } ];
                this.setData({
                    goods_items: o
                }), wx.hideLoading({
                    complete: function(e) {}
                });

              case 8:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return o.apply(this, arguments);
    }),
    onDeleteItem: (t = (0, i.default)(d.default.mark(function e(t) {
        var o, n;
        return d.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.log(t), e.prev = 1, o = this, e.next = 5, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "delete",
                        data: {
                            id: t.detail.data
                        }
                    }
                }).then(function(e) {
                    e.success || console.error(e);
                }).catch(function(e) {
                    console.log(e);
                });

              case 5:
                n = 0;

              case 6:
                if (!(n < o.data.goods_items.length)) {
                    e.next = 14;
                    break;
                }
                if (o.data.goods_items[n]._id != t.detail.data) {
                    e.next = 11;
                    break;
                }
                return wx.cloud.deleteFile({
                    fileList: o.data.goods_items[n].imgs,
                    success: function(e) {
                        console.log("delete:" + fileList);
                    },
                    fail: function(e) {
                        console.log(e);
                    },
                    complete: function(e) {
                        console.log(e);
                    }
                }), o.data.goods_items.splice(n, 1), e.abrupt("break", 14);

              case 11:
                n++, e.next = 6;
                break;

              case 14:
                this.setData({
                    goods_items: o.data.goods_items
                }), e.next = 20;
                break;

              case 17:
                e.prev = 17, e.t0 = e.catch(1), console.log(e.t0);

              case 20:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 1, 17 ] ]);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    onShowDetail: function(e) {
        console.debug(e);
        var t, o = this, n = e.currentTarget.dataset.index;
        wx.navigateTo({
            url: "../detail/detail",
            events: {
                dataChanged: (t = (0, i.default)(d.default.mark(function e(t) {
                    var a, i;
                    return d.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return console.debug(t), a = Object.keys(t), wx.showLoading({
                                title: "正在更新数据"
                            }), e.next = 5, wx.cloud.callFunction({
                                name: "goods-op",
                                data: {
                                    cmd: "update",
                                    id: o.data.goods_items[n]._id,
                                    data: t
                                }
                            }).then(function(e) {
                                console.debug(e);
                            }).catch(console.error);

                          case 5:
                            for (wx.hideLoading({
                                success: function(e) {}
                            }), a = Object.keys(t), i = 0; i < a.length; i++) o.data.goods_items[n][a[i]] = t[a[i]];
                            o.setData((0, s.default)({}, "goods_items[" + n + "]", o.data.goods_items[n]));

                          case 9:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function(e) {
                    return t.apply(this, arguments);
                })
            },
            success: function(t) {
                t.eventChannel.emit("showItem", o.data.goods_items[e.currentTarget.dataset.index], o.data._goodsTypes);
            }
        });
    },
    onHide: function() {
        console.log("hidden....");
    }
}, (0, s.default)(e, "onShow", function() {
    console.debug("admin onshow!");
}), (0, s.default)(e, "onUnload", function() {
    null != this.data._watcher && (console.debug("close watcher!"), this.data._watcher.close());
}), (0, s.default)(e, "onAddGoods", function(e) {
    console.debug(e);
    var t = this;
    wx.navigateTo({
        url: "../add/add-item",
        events: {
            goodsAdded: function(e) {
                if (console.debug(e), 0 != e.num) for (var o = t.data.goods_items.length, n = 0; n < e.num; n++) {
                    console.debug(e.items[n]);
                    var a = o + n;
                    t.setData((0, s.default)({}, "goods_items[" + a + "]", e.items[n]));
                } else console.debug("没有添加商品");
            }
        }
    });
}), (0, s.default)(e, "onReachBottom", function() {
    console.debug("bottom");
}), (0, s.default)(e, "onTabChanged", function(e) {
    console.debug(e), 2 == e.detail.index && this.onGetGoods(), this.setData({
        pageIndex: e.detail.index
    });
}), (0, s.default)(e, "onShareAppMessage", function(e) {}), (0, s.default)(e, "onReachBottom", function(e) {
    console.debug(e);
}), e));