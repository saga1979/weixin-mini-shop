var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/typeof"));

module.exports = function(t) {
    var r = {};
    function i(e) {
        if (r[e]) return r[e].exports;
        var o = r[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(o.exports, o, o.exports, i), o.l = !0, o.exports;
    }
    return i.m = t, i.c = r, i.d = function(e, t, r) {
        i.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: r
        });
    }, i.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, i.t = function(t, r) {
        if (1 & r && (t = i(t)), 8 & r) return t;
        if (4 & r && "object" === (0, e.default)(t) && t && t.__esModule) return t;
        var o = Object.create(null);
        if (i.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: t
        }), 2 & r && "string" != typeof t) for (var n in t) i.d(o, n, function(e) {
            return t[e];
        }.bind(null, n));
        return o;
    }, i.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return i.d(t, "a", t), t;
    }, i.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
    }, i.p = "", i(i.s = 2);
}([ function(e, t, r) {
    var i = !1, o = void 0, n = void 0;
    !function() {
        var e = wx.getSystemInfoSync();
        i = "ios" === e.platform;
        var t = e.screenWidth || 375, r = e.pixelRatio || 2;
        t === o && r === n || (o = t, n = r);
    }();
    var a = /([+-]?\d+(?:\.\d+)?)rpx/gi;
    e.exports = {
        transformRpx: function(e, t) {
            if ("string" != typeof e) return e;
            var r = a;
            return e.replace(r, function(e, r) {
                return (0 === (a = Number(r)) ? 0 : (a = a / 750 * o, 0 === (a = Math.floor(a + 1e-4)) ? 1 !== n && i ? .5 : 1 : a)) + (t ? "px" : "");
                var a;
            });
        }
    };
}, function(e, t, r) {
    e.exports = {};
}, function(e, t, r) {
    var i = r(3);
    e.exports = function(e) {
        return new i(e);
    };
}, function(t, r, i) {
    var o = "function" == typeof Symbol && "symbol" === (0, e.default)(Symbol.iterator) ? function(t) {
        return (0, e.default)(t);
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : (0, 
        e.default)(t);
    }, n = i(1), a = i(4), h = i(0);
    function s(e) {
        var t = this, r = e.id, i = e.dataKey, n = e.page, h = e.itemSize, s = e.useInPage, c = e.placeholderClass, l = e.root;
        if (!(r && i && n && h)) throw new Error("parameter id, dataKey, page, itemSize is required");
        if ("function" != typeof h && "object" !== (void 0 === h ? "undefined" : o(h))) throw new Error("parameter itemSize must be function or object with key width and height");
        if (!("object" !== (void 0 === h ? "undefined" : o(h)) || h.width && h.height || h.props && h.queryClass && h.dataKey)) throw new Error("parameter itemSize must be function or object with key width and height");
        if (this.id = r, this.dataKey = i, this.page = n, this.root = l, this.placeholderClass = c, 
        n._recycleViewportChange = a, this.comp = n.selectComponent("#" + r), this.itemSize = h, 
        this.itemSizeOpt = h, this.useInPage = s || !1, this.comp && (this.comp.context = this, 
        this.comp.setPage(n), this.comp.setUseInPage(this.useInPage)), this.useInPage && !this.root) throw new Error("parameter root is required when useInPage is true");
        this.useInPage && (this.oldPageScroll = this.root.onPageScroll, this.root.onPageScroll = function(e) {
            t.comp && t.comp._scrollViewDidScroll({
                detail: {
                    scrollLeft: 0,
                    scrollTop: e.scrollTop
                }
            }), t.oldPageScroll.apply(t.root, [ e ]);
        }, this.oldReachBottom = this.root.onReachBottom, this.root.onReachBottom = function(e) {
            t.comp && t.comp.triggerEvent("scrolltolower", {}), t.oldReachBottom.apply(t.root, [ e ]);
        }, this.oldPullDownRefresh = this.root.onPullDownRefresh, this.root.onPullDownRefresh = function(e) {
            t.comp && t.comp.triggerEvent("scrolltoupper", {}), t.oldPullDownRefresh.apply(t.root, [ e ]);
        });
    }
    function c(e, t) {
        if (!t) return e;
        if (void 0 !== e[t]) return e[t];
        for (var r = t.split("."), i = 0; i < r.length; i++) if (void 0 === (e = e[r[i]]) || "object" === (void 0 === e ? "undefined" : o(e)) && !e) return;
        return e;
    }
    function l(e, t) {
        "[object Array]" !== Object.prototype.toString.call(t) && (t = [ t ]);
        for (var r = {}, i = 0; i < t.length; i++) r[t[i]] = c(e, t[i]);
        return r;
    }
    function p(e) {
        return "[object Array]" === Object.prototype.toString.call(e);
    }
    function u(e, t) {
        if ((void 0 === e ? "undefined" : o(e)) !== (void 0 === t ? "undefined" : o(t))) return !1;
        if (p(e) && p(t)) {
            if (e.length !== t.length) return !1;
            for (var r = 0; r < e.length; r++) if (e[r] !== t[r]) return !1;
            return !0;
        }
        return e === t;
    }
    function f(e, t, r) {
        p(r) || (r = [ r ]);
        for (var i = 0; i < r.length; i++) if (!u(c(e, r[i]), c(t, r[i]))) return !1;
        return !0;
    }
    s.prototype.checkComp = function() {
        if (!this.comp) {
            if (this.comp = this.page.selectComponent("#" + this.id), !this.comp) throw new Error("the recycle-view correspond to this context is detached, pls create another RecycleContext");
            this.comp.setUseInPage(this.useInPage), this.comp.context = this, this.comp.setPage(this.page);
        }
    }, s.prototype.appendList = function(e, t) {
        this.checkComp();
        var r = this.id, i = this.dataKey;
        return n[r] ? (n[r].dataKey = i, n[r].list = n[r].list.concat(e)) : n[r] = {
            key: i,
            id: r,
            list: e,
            sizeMap: {},
            sizeArray: []
        }, this._forceRerender(r, t), this;
    }, s.prototype._forceRerender = function(e, t) {
        this.isDataReady = !0;
        var r = this, i = null, o = null, a = 0;
        function h() {
            if (i && o) {
                for (var e = [], t = 0; t < a; t++) e.push({
                    left: i[t].left - o.left,
                    top: i[t].top - o.top,
                    width: i[t].width,
                    height: i[t].height
                });
                r.comp.setPlaceholderImage(e, {
                    width: o.width,
                    height: o.height
                });
            }
        }
        function s() {
            if (t && t(), r.autoCalculateSize && r.placeholderClass) {
                var e = [];
                r.placeholderClass.forEach(function(t) {
                    e.push("." + r.itemSizeOpt.queryClass + " ." + t);
                }), a = e.length, wx.createSelectorQuery().selectAll(e.join(",")).boundingClientRect(function(e) {
                    e.length < a || (i = e, h());
                }).exec(), wx.createSelectorQuery().select("." + r.itemSizeOpt.queryClass).boundingClientRect(function(e) {
                    o = e, h();
                }).exec();
            }
        }
        if ("[object Object]" !== Object.prototype.toString.call(this.itemSizeOpt) || !this.itemSizeOpt || this.itemSizeOpt.width) {
            var c = this._recalculateSize(n[e].list);
            n[e].sizeMap = c.map, n[e].sizeArray = c.array, this.comp.forceUpdate(t);
        } else this._recalculateSizeByProp(n[e].list, function(t) {
            n[e].sizeMap = t.map, n[e].sizeArray = t.array, r.comp.forceUpdate(s);
        });
    }, s.prototype._recalculateSizeByProp = function(e, t) {
        var r = this.itemSizeOpt, i = this.propValueMap || [], o = [], n = [];
        r.cacheKey && (i = wx.getStorageSync(r.cacheKey) || []), this.autoCalculateSize = !0;
        for (var a = [], h = 0; h < e.length; h++) {
            var s = i.length;
            if (i.length) {
                for (var c = !1, p = 0; p < i.length; p++) if (f(i[p], e[h], r.props)) {
                    s = p, c = !0;
                    break;
                }
                if (!c) {
                    var u = l(e[h], r.props);
                    u.__index__ = h, i.push(u), o.push(e[h]), n.push(s);
                }
                a.push({
                    index: h,
                    sizeIndex: s
                });
            } else {
                var d = l(e[h], r.props);
                d.__index__ = h, i.push(d), o.push(e[h]), n.push(s), a.push({
                    index: h,
                    sizeIndex: s
                });
            }
        }
        this.propValueMap = i, i.length > 10 && console.warn("[recycle-view] get itemSize count exceed maximum of 10, now got", i);
        var g = this;
        function y(e, t) {
            var r = a[t];
            if (!r) throw console.error("[recycle-view] auto calculate size array error, no map size found", e, t, a), 
            new Error("[recycle-view] auto calculate size array error, no map size found");
            var o = i[r.sizeIndex];
            if (!o) throw console.log("[recycle-view] auto calculate size array error, no size found", e, t, r, i), 
            new Error("[recycle-view] auto calculate size array error, no size found");
            return {
                width: o.width,
                height: o.height
            };
        }
        if (o.length) {
            var m = {};
            m[r.dataKey] = o, this.page.setData(m, function() {
                wx.createSelectorQuery().selectAll("." + r.queryClass).boundingClientRect(function(o) {
                    !function(o) {
                        o.forEach(function(e, t) {
                            var r = n[t];
                            i[r].width = e.width, i[r].height = e.height;
                        }), g.itemSize = y;
                        var a = g._recalculateSize(e);
                        r.cacheKey && wx.setStorageSync(r.cacheKey, i), t && t(a);
                    }(o);
                }).exec();
            });
        } else {
            g.itemSize = y;
            var v = g._recalculateSize(e);
            t && t(v);
        }
    }, s.prototype._recalculateSize = function(e) {
        for (var t = {}, r = this.itemSize, i = "function" == typeof r, o = this.comp, n = o.data, a = 0, h = 0, s = 0, c = 0, l = [], p = e.length, u = 0; u < p; u++) {
            e[u].__index__ = u;
            var f = {};
            if (f = i ? r && r.call(this, e[u], u) : {
                width: r.width,
                height: r.height
            }, f = Object.assign({}, f), l.push(f), a + f.width > n.width) {
                if (c = 0, a = f.width, l.length >= 2 ? h += l[l.length - 2].height || 0 : h += f.height, 
                h >= 200 * (s + 1)) {
                    var d = u - 1, g = s;
                    s += parseInt((h - 200 * s) / 200, 10);
                    for (var y = g; y < s; y++) {
                        var m = y + "." + c;
                        t[m] || (t[m] = []), t[m].push(d);
                    }
                }
                if (0 === u) f.beforeHeight = 0; else {
                    var v = l[l.length - 2];
                    f.beforeHeight = v.beforeHeight + v.height;
                }
            } else a >= 200 * (c + 1) && c++, a += f.width, f.beforeHeight = 0 === u ? 0 : l[l.length - 2].beforeHeight;
            var w = s + "." + c;
            if (t[w] || (t[w] = []), t[w].push(u), p - 1 === u && f.height > 200) {
                var b = s;
                h += f.height, s += parseInt((h - 200 * s) / 200, 10);
                for (var S = b; S <= s; S++) {
                    var x = S + "." + c;
                    t[x] || (t[x] = []), t[x].push(u);
                }
            }
        }
        var z = {
            array: l,
            map: t,
            totalHeight: l.length ? l[l.length - 1].beforeHeight + l[l.length - 1].height : 0
        };
        return o.setItemSize(z), z;
    }, s.prototype.deleteList = function(e, t, r) {
        this.checkComp();
        var i = this.id;
        return n[i] ? (n[i].list.splice(e, t), this._forceRerender(i, r), this) : this;
    }, s.prototype.updateList = function(e, t, r) {
        this.checkComp();
        var i = this.id;
        if (!n[i]) return this;
        for (var o = n[i].list.length, a = 0; a < t.length && e < o; a++) n[i].list[e++] = t[a];
        return this._forceRerender(i, r), this;
    }, s.prototype.update = s.prototype.updateList, s.prototype.splice = function(e, t, r, i) {
        this.checkComp();
        var a = this.id, h = this.dataKey;
        if ("object" === (void 0 === e ? "undefined" : o(e)) && e.length && (i = t, r = e), 
        "function" == typeof r && (i = r, r = []), n[a]) {
            n[a].dataKey = h;
            var s = n[a].list;
            r && r.length ? s.splice.apply(s, [ e, t ].concat(r)) : s.splice(e, t);
        } else n[a] = {
            key: h,
            id: a,
            list: r || [],
            sizeMap: {},
            sizeArray: []
        };
        return this._forceRerender(a, i), this;
    }, s.prototype.append = s.prototype.appendList, s.prototype.destroy = function() {
        return this.useInPage && (this.page.onPullDownRefresh = this.oldPullDownRefresh, 
        this.page.onReachBottom = this.oldReachBottom, this.page.onPageScroll = this.oldPageScroll, 
        this.oldPageScroll = this.oldReachBottom = this.oldPullDownRefresh = null), this.page = null, 
        this.comp = null, n[this.id] && delete n[this.id], this;
    }, s.prototype.forceUpdate = function(e, t) {
        var r = this;
        return this.checkComp(), t ? this.comp.reRender(function() {
            r._forceRerender(r.id, e);
        }) : this._forceRerender(this.id, e), this;
    }, s.prototype.getBoundingClientRect = function(e) {
        if (this.checkComp(), !n[this.id]) return null;
        var t = n[this.id].sizeArray;
        if (!t || !t.length) return null;
        if (void 0 === e) {
            for (var r = [], i = 0; i < t.length; i++) r.push({
                left: 0,
                top: t[i].beforeHeight,
                width: t[i].width,
                height: t[i].height
            });
            return r;
        }
        return (e = parseInt(e, 10)) >= t.length || e < 0 ? null : {
            left: 0,
            top: t[e].beforeHeight,
            width: t[e].width,
            height: t[e].height
        };
    }, s.prototype.getScrollTop = function() {
        return this.checkComp(), this.comp.currentScrollTop || 0;
    }, s.prototype.transformRpx = s.transformRpx = function(e, t) {
        return "number" == typeof e && (e += "rpx"), parseFloat(h.transformRpx(e, t));
    }, s.prototype.getViewportItems = function(e) {
        this.checkComp();
        var t = this.comp.getIndexesInViewport(e);
        if (t.length <= 0) return [];
        for (var r = [], i = n[this.id].list, o = 0; o < t.length; o++) r.push(i[t[o]]);
        return r;
    }, s.prototype.getTotalHeight = function() {
        return this.checkComp(), this.comp.getTotalHeight();
    }, s.prototype.getList = function() {
        return n[this.id] ? n[this.id].list : [];
    }, t.exports = s;
}, function(e, t, r) {
    var i = r(1);
    e.exports = function(e, t) {
        var r = e.detail, o = [], n = i[r.id];
        if (n && n.list) {
            var a = n.list, h = r.data, s = h.beginIndex, c = h.endIndex;
            if (n.pos = h, void 0 === s || -1 === s || void 0 === c || -1 === c) o = []; else {
                var l = -1;
                for (l = s; l < a.length && l <= c; l++) l >= h.ignoreBeginIndex && l <= h.ignoreEndIndex || o.push(a[l]);
            }
            var p = {};
            p[n.key] = o;
            var u = this.selectComponent("#" + r.id);
            p[u.data.batchKey] = !this.data.batchSetRecycleData, u._setInnerBeforeAndAfterHeight({
                beforeHeight: h.minTop,
                afterHeight: h.afterHeight
            }), this.setData(p, function() {
                "function" == typeof t && t();
            });
        }
    };
} ]);