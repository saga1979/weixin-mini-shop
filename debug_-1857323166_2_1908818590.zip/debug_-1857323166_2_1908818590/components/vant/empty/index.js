var t = require("../common/component"), a = [ "error", "search", "default", "network" ];

(0, t.VantComponent)({
    props: {
        description: String,
        image: {
            type: String,
            value: "default"
        }
    },
    created: function() {
        -1 !== a.indexOf(this.data.image) ? this.setData({
            imageUrl: "https://img.yzcdn.cn/vant/empty-image-".concat(this.data.image, ".png")
        }) : this.setData({
            imageUrl: this.data.image
        });
    }
});