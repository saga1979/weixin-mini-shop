var t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/slicedToArray")), e = require("../common/component"), i = require("../common/utils");

(0, e.VantComponent)({
    props: {
        text: {
            type: String,
            value: "",
            observer: function() {
                var t = this;
                wx.nextTick(function() {
                    t.init();
                });
            }
        },
        mode: {
            type: String,
            value: ""
        },
        url: {
            type: String,
            value: ""
        },
        openType: {
            type: String,
            value: "navigate"
        },
        delay: {
            type: Number,
            value: 1
        },
        speed: {
            type: Number,
            value: 50,
            observer: function() {
                var t = this;
                wx.nextTick(function() {
                    t.init();
                });
            }
        },
        scrollable: {
            type: Boolean,
            value: !0
        },
        leftIcon: {
            type: String,
            value: ""
        },
        color: String,
        backgroundColor: String,
        background: String,
        wrapable: Boolean
    },
    data: {
        show: !0
    },
    created: function() {
        this.resetAnimation = wx.createAnimation({
            duration: 0,
            timingFunction: "linear"
        });
    },
    destroyed: function() {
        this.timer && clearTimeout(this.timer);
    },
    methods: {
        init: function() {
            var e = this;
            Promise.all([ i.getRect.call(this, ".van-notice-bar__content"), i.getRect.call(this, ".van-notice-bar__wrap") ]).then(function(i) {
                var n = (0, t.default)(i, 2), a = n[0], r = n[1];
                if (null != a && null != r && a.width && r.width) {
                    var o = e.data, l = o.speed, s = o.scrollable, c = o.delay;
                    if (s || r.width < a.width) {
                        var u = a.width / l * 1e3;
                        e.wrapWidth = r.width, e.contentWidth = a.width, e.duration = u, e.animation = wx.createAnimation({
                            duration: u,
                            timingFunction: "linear",
                            delay: c
                        }), e.scroll();
                    }
                }
            });
        },
        scroll: function() {
            var t = this;
            this.timer && clearTimeout(this.timer), this.timer = null, this.setData({
                animationData: this.resetAnimation.translateX(this.wrapWidth).step().export()
            }), (0, i.requestAnimationFrame)(function() {
                t.setData({
                    animationData: t.animation.translateX(-t.contentWidth).step().export()
                });
            }), this.timer = setTimeout(function() {
                t.scroll();
            }, this.duration);
        },
        onClickIcon: function(t) {
            "closeable" === this.data.mode && (this.timer && clearTimeout(this.timer), this.timer = null, 
            this.setData({
                show: !1
            }), this.$emit("close", t.detail));
        },
        onClick: function(t) {
            this.$emit("click", t);
        }
    }
});