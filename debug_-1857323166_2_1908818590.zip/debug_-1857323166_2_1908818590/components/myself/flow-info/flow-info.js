Page({
    data: {
        _flowInfo: {},
        steps: []
    },
    onLoad: function(t) {
        var o = this;
        wx.cloud.callFunction({
            name: "flow-op",
            data: {
                cmd: "get",
                data: {
                    no: t.no,
                    type: t.type
                }
            }
        }).then(function(t) {
            console.log(t), o.data._flowInfo = t.result.data;
            for (var n = 0; n < o.data._flowInfo.list.length; n++) o.data.steps.push({
                text: o.data._flowInfo.list[n].status,
                desc: o.data._flowInfo.list[n].time
            });
            o.setData({
                steps: o.data.steps
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});