var e, t, a, s = require("../../@babel/runtime/helpers/interopRequireDefault"), d = s(require("../../@babel/runtime/regenerator")), n = s(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        readonly: !1
    },
    onLoad: (a = (0, n.default)(d.default.mark(function e(t) {
        var a, s;
        return d.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.debug("address page loaded..."), console.debug(t), "true" == t.readonly && this.setData({
                    readonly: !0
                }), e.next = 5, wx.cloud.callFunction({
                    name: "users-op",
                    data: {
                        cmd: "address-get"
                    }
                });

              case 5:
                if (a = e.sent, console.debug(a.result), a.result.success) {
                    e.next = 9;
                    break;
                }
                return e.abrupt("return");

              case 9:
                for (this.data.addressBook = a.result.data[0].addressBook, s = 0; s < this.data.addressBook.length; s++) this.data.addressBook[s].slideButtons = [ {
                    text: "删除",
                    data: s,
                    type: "warn"
                } ];
                this.setData({
                    addressBook: this.data.addressBook
                });

              case 12:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return a.apply(this, arguments);
    }),
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onDeleteItem: function(e) {
        console.debug(e);
    },
    onSelectAddressItem: function(e) {
        console.debug(e);
        var t = e.currentTarget.dataset.index;
        this.data.readonly ? (this.getOpenerEventChannel().emit("addressSelected", this.data.addressBook[t]), 
        wx.navigateBack({
            delta: 0
        })) : wx.navigateTo({
            url: "../address-detail/address-detail"
        });
    },
    onFromWeixin: (t = (0, n.default)(d.default.mark(function e(t) {
        var a;
        return d.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                a = this, wx.chooseAddress({
                    success: function() {
                        var e = (0, n.default)(d.default.mark(function e(t) {
                            var s, n;
                            return d.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return console.debug(t), s = {
                                        detailInfo: t.detailInfo,
                                        isDefault: !1,
                                        telNumber: t.telNumber,
                                        userName: t.userName
                                    }, e.next = 4, wx.cloud.callFunction({
                                        name: "users-op",
                                        data: {
                                            cmd: "address-add",
                                            data: s
                                        }
                                    });

                                  case 4:
                                    1 == (n = e.sent).result.data ? (s.slideButtons = [ {
                                        text: "删除",
                                        data: a.data.addressBook.length,
                                        type: "warn"
                                    } ], a.data.addressBook.push(s), a.setData({
                                        addressBook: a.data.addressBook
                                    })) : wx.showToast({
                                        title: n.result.success ? "已存在数据" : "数据保存失败"
                                    });

                                  case 6:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }(),
                    fail: function(e) {
                        console.log(e);
                    }
                });

              case 2:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    onDeleteAddressItem: (e = (0, n.default)(d.default.mark(function e(t) {
        var a, s;
        return d.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.debug(t), a = t.detail.data, e.next = 4, wx.cloud.callFunction({
                    name: "users-op",
                    data: {
                        cmd: "address-del",
                        data: {
                            address: {
                                detailInfo: this.data.addressBook[a].detailInfo,
                                isDefault: this.data.addressBook[a].isDefault,
                                telNumber: this.data.addressBook[a].telNumber,
                                userName: this.data.addressBook[a].userName
                            },
                            index: t.detail.data
                        }
                    }
                });

              case 4:
                (s = e.sent).result.success && s.result.data > 0 && (this.data.addressBook.splice(a, 1), 
                this.setData({
                    addressBook: this.data.addressBook
                })), console.debug(s);

              case 7:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onSelectAddress: function(e) {
        wx.navigateBack({
            delta: 0
        });
    }
});