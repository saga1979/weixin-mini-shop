var t, e, a, s = require("../../@babel/runtime/helpers/interopRequireDefault"), o = s(require("../../@babel/runtime/helpers/defineProperty")), i = s(require("../../@babel/runtime/regenerator")), r = s(require("../../@babel/runtime/helpers/asyncToGenerator"));

Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        nickName: {
            type: String,
            value: ""
        },
        avatarUrl: String
    },
    data: {
        _removedList: [],
        goodsList: [],
        totalPrice: 0,
        _dirty: !1,
        _originalCart: [],
        _discounts: []
    },
    lifetimes: {
        created: function() {
            console.debug("created");
        },
        attached: (a = (0, r.default)(i.default.mark(function t() {
            var e, a, s, o;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return console.debug("attached"), this.data._dirty = !1, wx.showLoading({
                        title: "正在请求数据"
                    }), t.next = 5, wx.cloud.callFunction({
                        name: "discount",
                        data: {
                            cmd: "get-valid"
                        }
                    });

                  case 5:
                    if ((e = t.sent).result.success) {
                        t.next = 10;
                        break;
                    }
                    return wx.showModal({
                        title: "错误",
                        content: "获取数据失败"
                    }), wx.hideLoading({
                        success: function(t) {}
                    }), t.abrupt("return");

                  case 10:
                    return console.debug("discount:", e.result), this.data._discounts = e.result.data, 
                    a = this, t.next = 15, wx.cloud.callFunction({
                        name: "cart-op",
                        data: {
                            cmd: "get"
                        }
                    });

                  case 15:
                    e = t.sent, console.debug(e.result.data.list), s = [], e.result.data.list.forEach(function(t) {
                        a.data._originalCart.push(t.cart), t.goodsInfo[0].buttons = [ {
                            text: "删除",
                            type: "warn",
                            data: t.goodsInfo[0]._id
                        } ], t.goodsInfo[0].isSelling || (a.data._dirty = !0), t.cart.selected && t.goodsInfo[0].isSelling && (t.goodsInfo[0].selected = t.cart.selected, 
                        t.goodsInfo[0].count = t.cart.count, t.goodsInfo[0].order_price = Number((t.goodsInfo[0].price * t.cart.count).toFixed(2))), 
                        t.goodsInfo[0].discounts = [], a.data._discounts.forEach(function(e) {
                            -1 != e.goods.indexOf(t.goodsInfo[0]._id) && t.goodsInfo[0].discounts.push({
                                title: e.title
                            });
                        }), s.push(t.goodsInfo[0]);
                    }), o = a.calculate(s, a.data._discounts), a.setData({
                        goodsList: s,
                        totalPrice: o
                    }), console.debug("goods:", this.data.goodsList), wx.hideLoading({
                        success: function(t) {}
                    });

                  case 23:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return a.apply(this, arguments);
        }),
        moved: function() {
            console.debug("moved");
        },
        detached: (e = (0, r.default)(i.default.mark(function t() {
            var e, a, s;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (console.debug("cart detached"), e = [], this.data.goodsList.forEach(function(t) {
                        var a = {
                            id: t._id,
                            count: t.count,
                            selected: t.selected
                        };
                        e.push(a);
                    }), a = this, e.forEach(function(t) {
                        var e = a.data._originalCart.findIndex(function(e) {
                            return e.id == t.id;
                        });
                        -1 != e ? t.id == a.data._originalCart[e].id && t.selected == a.data._originalCart[e].selected && t.count == a.data._originalCart[e].count || (a.data._dirty = !0) : a.data._dirty;
                    }), e.length != this.data._originalCart.length && (this.data._dirty = !0), console.debug("dirty:", this.data._dirty), 
                    this.data._dirty) {
                        t.next = 9;
                        break;
                    }
                    return t.abrupt("return");

                  case 9:
                    return wx.showLoading({
                        title: "更新状态"
                    }), t.next = 12, wx.cloud.callFunction({
                        name: "cart-op",
                        data: {
                            cmd: "save",
                            cart: e
                        }
                    });

                  case 12:
                    s = t.sent, console.debug(s), wx.hideLoading({
                        success: function(t) {}
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        }),
        ready: function() {
            console.debug("ready");
        }
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {
            console.debug("hide");
        },
        resize: function() {}
    },
    methods: {
        onNumChanged: function(t) {
            console.log(t);
            var e = t.target.dataset.index;
            null == this.data.goodsList[e].order_price && (this.data.goodsList[e].order_price = 0);
            var a = Number(this.data.goodsList[e].order_price.toFixed(2)), s = Number((this.data.goodsList[e].price * t.detail).toFixed(2));
            if (this.data.goodsList[e].order_price = s, this.data.goodsList[e].count = t.detail, 
            console.log("new order:" + s), console.log("old order:" + a), this.data.goodsList[e].selected) {
                this.setData((0, o.default)({}, "goodsList[" + e + "].order_price", s));
                var i = this.calculate(this.data.goodsList, this.data._discounts);
                this.setData({
                    totalPrice: i
                });
            } else this.setData((0, o.default)({}, "goodsList[" + e + "].order_price", s));
        },
        onDeleteItem: function(t) {
            console.log(t), this.data._removedList.push(t.detail.data);
            var e = this.data.goodsList.findIndex(function(e) {
                return e._id == t.detail.data;
            });
            console.debug("index:", e);
            var a = !1;
            if (this.data.goodsList[e].selected && (a = !0), this.data.goodsList.splice(e, 1), 
            this.setData({
                goodsList: this.data.goodsList
            }), a) {
                var s = this.calculate(this.data.goodsList, this.data._discounts);
                this.setData({
                    totalPrice: s
                });
            }
        },
        onItemClicked: function(t) {
            console.debug(t);
            var e = t.target.dataset.index, a = !this.data.goodsList[e].selected;
            if (a && (0 == this.data.goodsList[e].count || null == this.data.goodsList[e].count)) {
                var s, i = Number((1 * this.data.goodsList[e].price).toFixed(2));
                this.setData((s = {}, (0, o.default)(s, "goodsList[".concat(e, "].order_price"), i), 
                (0, o.default)(s, "goodsList[".concat(e, "].count"), 1), s));
            }
            this.setData((0, o.default)({}, "goodsList[" + e + "].selected", a));
            var r = this.calculate(this.data.goodsList, this.data._discounts);
            this.setData({
                totalPrice: r
            });
        },
        onSubmitOrder: (t = (0, r.default)(i.default.mark(function t(e) {
            var a, s, d, n, c, u, l;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (0 != this.data.totalPrice) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.next = 4, wx.cloud.callFunction({
                        name: "users-op",
                        data: {
                            cmd: "address-get",
                            limit: 1
                        }
                    });

                  case 4:
                    if (a = t.sent, console.debug(a), 0 != a.result.data.length) {
                        t.next = 9;
                        break;
                    }
                    return wx.showToast({
                        title: "请先配置收货地址",
                        duration: 1500
                    }), t.abrupt("return");

                  case 9:
                    s = this, d = [], n = [], c = 0;

                  case 13:
                    if (!(c < this.data.goodsList.length)) {
                        t.next = 22;
                        break;
                    }
                    if ((u = this.data.goodsList[c]).selected) {
                        t.next = 17;
                        break;
                    }
                    return t.abrupt("continue", 19);

                  case 17:
                    d.push({
                        id: u._id,
                        count: u.count,
                        price: u.price,
                        name: u.name,
                        img: u.imgs[0],
                        desc: u.des
                    }), n.push(c);

                  case 19:
                    c++, t.next = 13;
                    break;

                  case 22:
                    l = {
                        nickName: this.data.nickName,
                        time: new Date(),
                        list: d,
                        sum: this.data.totalPrice / 100
                    }, wx.navigateTo({
                        url: "../order-submit/order-submit?address=" + JSON.stringify(a.result.data[0]),
                        events: {
                            submitOrder: function() {
                                var t = (0, r.default)(i.default.mark(function t(e) {
                                    return i.default.wrap(function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                          case 0:
                                            return console.debug(e), t.next = 3, wx.cloud.callFunction({
                                                name: "orders-op",
                                                data: {
                                                    cmd: "add",
                                                    data: {
                                                        nickName: s.data.nickName,
                                                        list: d,
                                                        sum: s.data.totalPrice / 100,
                                                        address: e.address,
                                                        time: e.time,
                                                        timeline: e.payed ? [ {
                                                            time: e.time,
                                                            status: "您已提交订单，等待确认"
                                                        } ] : [ {
                                                            time: e.time,
                                                            status: "您已提交订单，等待支付"
                                                        } ],
                                                        stage: {
                                                            value: e.payed ? 1 : 0,
                                                            title: e.payed ? "待确认" : "待付款"
                                                        },
                                                        hidden: !1,
                                                        NO: e.NO
                                                    }
                                                }
                                            });

                                          case 3:
                                            if (t.sent.result.success) {
                                                t.next = 7;
                                                break;
                                            }
                                            return wx.showToast({
                                                title: "未能保存订单"
                                            }), t.abrupt("return");

                                          case 7:
                                            wx.showToast({
                                                title: "订单已提交"
                                            }), n.forEach(function(t) {
                                                s.setData((0, o.default)({}, "goodsList[".concat(t, "].selected"), !1));
                                            }), s.setData({
                                                totalPrice: 0
                                            });

                                          case 10:
                                          case "end":
                                            return t.stop();
                                        }
                                    }, t);
                                }));
                                return function(e) {
                                    return t.apply(this, arguments);
                                };
                            }()
                        },
                        success: function(t) {
                            t.eventChannel.emit("acceptDataFromOrder", l);
                        }
                    });

                  case 24:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(e) {
            return t.apply(this, arguments);
        }),
        calculate: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], a = 0, s = [];
            t.forEach(function(t) {
                t.selected && (t.order_price = Number((t.price * t.count).toFixed(2)), a += 100 * t.order_price, 
                s.push(t));
            });
            var o = s.sort(function(t, e) {
                return t.price - e.price;
            });
            console.debug("sorted:", o);
            for (var i = [], r = 0; r < e.length; r++) {
                var d = [], n = 0, c = 0;
                o.forEach(function(t) {
                    -1 != e[r].goods.indexOf(t._id) && (d.push(t), n += t.count, c += t.order_price);
                });
                var u = 0;
                switch (e[r].type) {
                  case "1":
                    c >= e[r].total && i.push({
                        title: e[r].title,
                        cut: 100 * e[r].cut
                    });
                    break;

                  case "2":
                    var l = Number.parseInt(c / e[r].total);
                    l > 0 && i.push({
                        title: e[r].title,
                        cut: e[r].title.cut * l * 100
                    });
                    break;

                  case "3":
                    if (n < e[r].total) break;
                    for (var h = e[r].cut, g = 0; h > 0; ) {
                        var f = 1;
                        h - d[g].count > 0 ? (h -= d[g].count, f = d[g].count) : (f = h, h = 0), u += 100 * Number((d[g].price * f).toFixed(2)), 
                        g++;
                    }
                    i.push({
                        title: e[r].title,
                        cut: u
                    });
                }
            }
            var p = i.sort(function(t, e) {
                return t.cut - e.cut;
            });
            return console.debug("totalPrice:", a), console.debug("sortedCutPriceList:", p), 
            0 == p.length ? a : a - p[p.length - 1].cut;
        }
    }
});