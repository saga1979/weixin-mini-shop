var e, t, a, s = require("../../@babel/runtime/helpers/interopRequireDefault"), n = s(require("../../@babel/runtime/helpers/defineProperty")), o = s(require("../../@babel/runtime/regenerator")), d = s(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        goodsTypes: [],
        _deletedTypes: []
    },
    onLoad: (a = (0, d.default)(o.default.mark(function e(t) {
        var a, s, n;
        return o.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return wx.showLoading({
                    title: "正在获取数据"
                }), e.next = 3, wx.cloud.callFunction({
                    name: "config",
                    data: {
                        cmd: "goodsTypes-get"
                    }
                });

              case 3:
                if (a = e.sent, wx.hideLoading({
                    success: function(e) {}
                }), console.debug(a.result.data), null != (s = a.result.data)) {
                    e.next = 9;
                    break;
                }
                return e.abrupt("return");

              case 9:
                for (n = 0; n < s.length; n++) s[n].buttons = [ {
                    text: "删除",
                    type: "warn",
                    src: "../../../images/trash.png",
                    data: s[n]._id
                } ];
                this.setData({
                    goodsTypes: s
                });

              case 11:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return a.apply(this, arguments);
    }),
    onReady: function() {},
    onTitleInput: function(e) {
        var t = this.data.goodsTypes[e.target.dataset.index];
        null == t.old_title && null == t.new_stable && (this.data.goodsTypes[e.target.dataset.index].old_title = this.data.goodsTypes[e.target.dataset.index].title), 
        this.data.goodsTypes[e.target.dataset.index].title = e.detail.value;
    },
    onDescInput: function(e) {
        var t = this.data.goodsTypes[e.target.dataset.index];
        null == t.old_desc && null == t.new_stable && (this.data.goodsTypes[e.target.dataset.index].old_desc = this.data.goodsTypes[e.target.dataset.index].desc), 
        this.data.goodsTypes[e.target.dataset.index].desc = e.detail.value;
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: (t = (0, d.default)(o.default.mark(function e() {
        var t, a, s, n, d, i, r;
        return o.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                t = [], a = [], s = [], console.debug("goodsTypes:", this.data.goodsTypes), n = 0;

              case 5:
                if (!(n < this.data.goodsTypes.length)) {
                    e.next = 34;
                    break;
                }
                if (!(d = this.data.goodsTypes[n]).deleted) {
                    e.next = 11;
                    break;
                }
                return s.push(n), e.abrupt("continue", 31);

              case 11:
                if (0 != Object.keys(d).filter(function(e) {
                    return e.startsWith("old_");
                }).length || 0 != Object.keys(d).filter(function(e) {
                    return e.startsWith("new_");
                }).length) {
                    e.next = 13;
                    break;
                }
                return e.abrupt("continue", 31);

              case 13:
                if (d.old_title != d.title || d.old_desc != d.desc) {
                    e.next = 15;
                    break;
                }
                return e.abrupt("continue", 31);

              case 15:
                if (i = {
                    title: d.title,
                    desc: d.desc,
                    img: d.img,
                    index: n
                }, d.img.startsWith("cloud://") && null == d.old_img) {
                    e.next = 28;
                    break;
                }
                return wx.showLoading({
                    title: "正在上传图片"
                }), e.next = 20, wx.cloud.uploadFile({
                    cloudPath: d.imgCloud,
                    filePath: d.img
                });

              case 20:
                if (r = e.sent, i.img = r.fileID, null == d.old_img) {
                    e.next = 27;
                    break;
                }
                return e.next = 25, wx.cloud.deleteFile({
                    fileList: [ d.old_img ]
                });

              case 25:
                r = e.sent, console.debug("已删除:", r.fileList);

              case 27:
                wx.hideLoading({
                    success: function(e) {}
                });

              case 28:
                console.debug("type:", i), console.debug("keys:", Object.keys(d).filter(function(e) {
                    return e.startsWith("old_");
                })), 0 != Object.keys(d).filter(function(e) {
                    return e.startsWith("old_");
                }).length ? t.push(i) : (delete i.index, a.push(i));

              case 31:
                n++, e.next = 5;
                break;

              case 34:
                if (0 != t.length || 0 != a.length || 0 != s.length) {
                    e.next = 37;
                    break;
                }
                return console.debug("没有更改信息"), e.abrupt("return");

              case 37:
                return wx.showLoading({
                    title: "正在变更信息"
                }), console.debug(t), e.next = 41, wx.cloud.callFunction({
                    name: "config",
                    data: {
                        cmd: "goodsTypes-set",
                        data: {
                            modified: t,
                            added: a,
                            deleted: s
                        }
                    }
                });

              case 41:
                r = e.sent, wx.hideLoading({
                    success: function(e) {}
                }), console.debug(r);

              case 44:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return t.apply(this, arguments);
    }),
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onClickItem: function(e) {
        console.debug(e);
        var t = e.target.dataset.index;
        1 == e.detail.index ? this.setData((0, n.default)({}, "goodsTypes[".concat(t, "].editable"), !0)) : (this.data._deletedTypes.push(this.data.goodsTypes[t]), 
        this.data.goodsTypes[t].deleted = !0, this.setData((0, n.default)({}, "goodsTypes[".concat(t, "].deleted"), !0)));
    },
    onAddType: (e = (0, d.default)(o.default.mark(function e(t) {
        var a, s, d, i;
        return o.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return a = null, e.prev = 1, e.next = 4, wx.chooseImage({
                    count: 1,
                    sizeType: [ "compressed" ],
                    sourceType: [ "album", "camera" ]
                });

              case 4:
                a = e.sent, e.next = 10;
                break;

              case 7:
                e.prev = 7, e.t0 = e.catch(1);

              case 10:
                if (null != a) {
                    e.next = 13;
                    break;
                }
                return wx.showModal({
                    title: "提示",
                    content: "必须为类别选择图片"
                }), e.abrupt("return");

              case 13:
                console.debug("choose image:", null == a ? "fail" : a), (s = {
                    title: "",
                    img: a.tempFilePaths[0],
                    desc: "",
                    editable: !0
                }).buttons = [ {
                    text: "删除",
                    type: "warn",
                    data: s.title
                }, {
                    text: "编辑",
                    type: "primary",
                    data: s.title
                } ], d = "configs/" + Date.now() + "[0]" + s.img.match(/\.[^.]+?$/)[0], s.imgCloud = d, 
                this.data.goodsTypes.push(s), i = this.data.goodsTypes.length - 1, this.setData((0, 
                n.default)({}, "goodsTypes[".concat(i, "]"), this.data.goodsTypes[i])), this.data.goodsTypes[i].new_stable = {
                    index: this.data.goodsTypes.length - 1
                }, console.debug(this.data.goodsTypes);

              case 23:
              case "end":
                return e.stop();
            }
        }, e, this, [ [ 1, 7 ] ]);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onSelectImg: function(e) {
        var t = e.target.dataset.index, a = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var s = Date.now().toString(16) + Math.random().toString(16) + "0".repeat(16), o = ([ s.substr(0, 8), s.substr(8, 4), "4000-8" + s.substr(13, 3), s.substr(16, 12) ].join("-"), 
                "configs/" + Date.now() + "[0]" + e.tempFilePaths[0].match(/\.[^.]+?$/)[0]);
                console.log(o), a.data.goodsTypes[t].imgCloud = o, a.data.goodsTypes[t].img.startsWith("cloud://") && (a.data.goodsTypes[t].old_img = a.data.goodsTypes[t].img), 
                a.setData((0, n.default)({}, "goodsTypes[".concat(t, "].img"), e.tempFilePaths[0]));
            },
            fail: function(e) {
                console.error(e);
            }
        });
    }
});