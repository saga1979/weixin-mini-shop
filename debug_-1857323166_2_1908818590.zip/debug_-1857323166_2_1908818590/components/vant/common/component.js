var e = require("../../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.VantComponent = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = {};
    s(e, n, {
        data: "data",
        props: "properties",
        mixins: "behaviors",
        methods: "methods",
        beforeCreate: "created",
        created: "attached",
        mounted: "ready",
        relations: "relations",
        destroyed: "detached",
        classes: "externalClasses"
    });
    var t = e.relation;
    t && r(n, e, t);
    n.externalClasses = n.externalClasses || [], n.externalClasses.push("custom-class"), 
    n.behaviors = n.behaviors || [], n.behaviors.push(i.basic), e.field && n.behaviors.push("wx://form-field");
    n.properties && Object.keys(n.properties).forEach(function(e) {
        Array.isArray(n.properties[e]) && (n.properties[e] = null);
    });
    n.options = {
        multipleSlots: !0,
        addGlobalClass: !0
    }, Component(n);
};

var n = e(require("../../../@babel/runtime/helpers/defineProperty")), i = require("../mixins/basic"), t = {
    ancestor: {
        linked: function(e) {
            this.parent = e;
        },
        unlinked: function() {
            this.parent = null;
        }
    },
    descendant: {
        linked: function(e) {
            this.children = this.children || [], this.children.push(e);
        },
        unlinked: function(e) {
            this.children = (this.children || []).filter(function(n) {
                return n !== e;
            });
        }
    }
};

function s(e, n, i) {
    Object.keys(i).forEach(function(t) {
        e[t] && (n[i[t]] = e[t]);
    });
}

function r(e, i, s) {
    var r = s.type, a = s.name, d = s.linked, o = s.unlinked, l = s.linkChanged, c = i.beforeCreate, h = i.destroyed;
    "descendant" === r && (e.created = function() {
        c && c.bind(this)(), this.children = this.children || [];
    }, e.detached = function() {
        this.children = [], h && h.bind(this)();
    }), e.relations = Object.assign(e.relations || {}, (0, n.default)({}, "../".concat(a, "/index"), {
        type: r,
        linked: function(e) {
            t[r].linked.bind(this)(e), d && d.bind(this)(e);
        },
        linkChanged: function(e) {
            l && l.bind(this)(e);
        },
        unlinked: function(e) {
            t[r].unlinked.bind(this)(e), o && o.bind(this)(e);
        }
    }));
}