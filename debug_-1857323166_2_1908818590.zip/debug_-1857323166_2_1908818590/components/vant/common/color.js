Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.GRAY_DARK = exports.GRAY = exports.ORANGE = exports.GREEN = exports.WHITE = exports.BLUE = exports.RED = void 0;

exports.RED = "#ee0a24";

exports.BLUE = "#1989fa";

exports.WHITE = "#fff";

exports.GREEN = "#07c160";

exports.ORANGE = "#ff976a";

exports.GRAY = "#323233";

exports.GRAY_DARK = "#969799";