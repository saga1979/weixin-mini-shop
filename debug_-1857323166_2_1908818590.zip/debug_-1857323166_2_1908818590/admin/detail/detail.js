var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty"));

Page({
    data: {},
    observers: {
        des: function() {
            console.debug("lksdfkdsf");
        }
    },
    attached: function() {
        console.debug("att");
    },
    onLoad: function(t) {
        var n = this;
        this.getOpenerEventChannel().on("showItem", function(t, o) {
            for (var a = Object.keys(t), s = 0; s < a.length; s++) {
                console.debug(a[s], t[a[s]]);
                var d = a[s];
                n.setData((0, e.default)({}, "".concat(d), t[a[s]]));
            }
            n.data._oldItem = t, n.setData({
                _goodsTypes: o,
                _goodsType: o.indexOf(n.data.type)
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        console.debug("admin detail onshow!");
    },
    onHide: function() {
        console.log("goods item detail page hidden!");
    },
    onUnload: function() {
        var e = this.getOpenerEventChannel(), t = {}, n = Object.keys(this.data).filter(function(e) {
            return !e.startsWith("_");
        });
        console.debug("keys:", n);
        for (var o = 0; o < n.length; o++) this.data[n[o]] != this.data._oldItem[n[o]] && (t[n[o]] = this.data[n[o]]);
        0 != Object.keys(t).length ? e.emit("dataChanged", t) : console.debug("没有更改商品信息");
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    bindTypeChange: function(e) {
        console.debug(e), this.setData({
            type: this.data._goodsTypes[e.detail.value]
        });
    }
});