var t, e, s = require("../../@babel/runtime/helpers/interopRequireDefault"), a = s(require("../../@babel/runtime/helpers/defineProperty")), i = s(require("../../@babel/runtime/regenerator")), n = s(require("../../@babel/runtime/helpers/asyncToGenerator"));

Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {},
    data: {
        itemTitle: "筛选",
        statisticsType: 1,
        statisticsTypes: [ {
            text: "按商品",
            value: 0,
            checked: !0
        }, {
            text: "按客户",
            value: 1,
            checked: !1
        } ],
        switchTypes: [ {
            title: "待付款",
            value: 0,
            checked: !0
        }, {
            title: "待确认",
            value: 1,
            checked: !0
        }, {
            title: "进行中",
            value: 2,
            checked: !1
        }, {
            title: "已完成",
            value: 3,
            checked: !1
        }, {
            title: "已取消",
            value: 4,
            checked: !1
        } ],
        userList: [],
        goodsList: [],
        stages: [ 0, 1 ]
    },
    lifetimes: {
        created: function() {},
        attached: function() {},
        detached: function() {},
        ready: (e = (0, n.default)(i.default.mark(function t() {
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    this.getStatistics(0 == this.data.statisticsType ? "goods" : "user", this.data.stages);

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function() {
            return e.apply(this, arguments);
        })
    },
    pageLifetimes: {},
    methods: {
        onIncludeProcessingChange: function(t) {},
        onIncludeDoneChange: function(t) {},
        onConfirm: function(t) {
            var e = [];
            this.data.switchTypes.forEach(function(t) {
                t.checked && e.push(t.value);
            }), this.data.stages = e, this.getStatistics(0 == this.data.statisticsType ? "goods" : "user", e);
        },
        onSwitchStatistics: function(t) {
            console.debug(t), this.data.statisticsType != t.detail && (this.setData({
                statisticsType: t.detail
            }), this.getStatistics(0 == t.detail ? "goods" : "user", this.data.stages));
        },
        onShowDetail: function(t) {
            console.debug(t), wx.navigateTo({
                url: "../order-op/order-op?openid=" + t.currentTarget.dataset.openid + "&value=" + this.data.stages
            });
        },
        onOrderTypeChanged: function(t) {
            console.debug(t), this.setData((0, a.default)({}, "switchTypes[".concat(t.target.dataset.index, "].checked"), t.detail)), 
            console.debug(this.data.switchTypes);
        },
        getStatistics: (t = (0, n.default)(i.default.mark(function t(e, s) {
            var a, n;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = "statistics-by-goods", "goods" == e || (a = "statistics-by-user"), t.next = 4, 
                    wx.cloud.callFunction({
                        name: "orders-op",
                        data: {
                            cmd: a,
                            data: {
                                stages: s
                            }
                        }
                    });

                  case 4:
                    n = t.sent, console.debug(n.result), "goods" == e ? this.setData({
                        goodsList: n.result.data
                    }) : this.setData({
                        userList: n.result.data
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(e, s) {
            return t.apply(this, arguments);
        })
    }
});