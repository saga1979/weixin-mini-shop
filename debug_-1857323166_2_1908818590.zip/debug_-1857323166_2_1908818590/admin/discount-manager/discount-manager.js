var t, e = require("../../@babel/runtime/helpers/interopRequireDefault"), n = e(require("../../@babel/runtime/helpers/defineProperty")), a = e(require("../../@babel/runtime/regenerator")), o = e(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        showDialog: !1,
        groups: [ {
            text: "满减（一次）",
            value: 1
        }, {
            text: "满减（叠加）",
            value: 2
        }, {
            text: "免单",
            value: 3
        } ]
    },
    onLoad: (t = (0, o.default)(a.default.mark(function t(e) {
        var n;
        return a.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                n = this, wx.cloud.callFunction({
                    name: "discount",
                    data: {
                        cmd: "get"
                    }
                }).then(function(t) {
                    for (var e = t.result.data, a = 0; a < e.length; a++) e[a].buttons = [ {
                        text: "删除",
                        data: e._id
                    } ];
                    n.setData({
                        discountInfos: e
                    }), console.debug(n.data.discountInfos);
                }).catch(function(t) {
                    console.error(t);
                });

              case 2:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    openDialog: function() {
        this.setData({
            showDialog: !0
        });
    },
    closeDialog: function() {
        this.setData({
            showDialog: !1
        });
    },
    btnClick: function(t) {
        console.log(t), this.closeDialog();
        var e, n = this;
        wx.navigateTo({
            url: "../discount/discount?type=" + t.detail.value,
            events: {
                add: (e = (0, o.default)(a.default.mark(function t(e) {
                    var o, u;
                    return a.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return console.log(e), t.next = 3, wx.cloud.callFunction({
                                name: "discount",
                                data: {
                                    cmd: "add",
                                    data: e
                                }
                            });

                          case 3:
                            o = t.sent, u = e, n.data.discountInfos.length, u._id = o.data, n.data.discountInfos.push(u), 
                            n.setData({
                                discountInfos: n.data.discountInfos
                            });

                          case 9:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                })), function(t) {
                    return e.apply(this, arguments);
                })
            }
        });
    },
    toDetail: function(t) {
        console.debug(t);
        var e, u = this;
        wx.navigateTo({
            url: "../discount/discount?_id=" + t.target.dataset.id,
            events: {
                update: (e = (0, o.default)(a.default.mark(function t(e) {
                    var o;
                    return a.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return console.debug("new update:", e), t.next = 3, wx.cloud.callFunction({
                                name: "discount",
                                data: {
                                    cmd: "update",
                                    data: {
                                        id: e.id,
                                        update: e.update
                                    }
                                }
                            });

                          case 3:
                            t.sent, -1 != (o = u.data.discountInfos.findIndex(function(t) {
                                return t._id == e.id;
                            })) && null != e.update.title && (u.data.discountInfos[o].title = e.update.title, 
                            u.setData((0, n.default)({}, "discountInfos[" + o + "].title", u.data.discountInfos[o].title)));

                          case 6:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                })), function(t) {
                    return e.apply(this, arguments);
                })
            }
        });
    },
    discountOnorOff: function(t) {
        console.debug(t), this.setData((0, n.default)({}, "discountInfos[" + t.target.dataset.index + "].stopped", !t.detail.value)), 
        wx.cloud.callFunction({
            name: "discount",
            data: {
                cmd: "update",
                data: {
                    id: this.data.discountInfos[t.target.dataset.index]._id,
                    update: {
                        stopped: !t.detail.value
                    }
                }
            }
        }).then(function(t) {
            console.debug("update:", t);
        }).catch(function(t) {
            console.debug(t);
        });
    },
    onDeleteItem: function(t) {
        console.debug(t);
        var e = this;
        wx.cloud.callFunction({
            name: "discount",
            data: {
                cmd: "delete",
                ids: [ t.target.dataset.id ]
            }
        }).then(function(a) {
            e.setData((0, n.default)({}, "discountInfos[" + t.target.dataset.index + "].hidden", !0));
        }).catch(function(t) {
            console.error(t);
        });
    }
});