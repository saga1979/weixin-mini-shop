var t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/typeof"));

module.exports = function(e) {
    var a = {};
    function r(t) {
        if (a[t]) return a[t].exports;
        var n = a[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(n.exports, n, n.exports, r), n.l = !0, n.exports;
    }
    return r.m = e, r.c = a, r.d = function(t, e, a) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: a
        });
    }, r.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        });
    }, r.t = function(e, a) {
        if (1 & a && (e = r(e)), 8 & a) return e;
        if (4 & a && "object" === (0, t.default)(e) && e && e.__esModule) return e;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
            enumerable: !0,
            value: e
        }), 2 & a && "string" != typeof e) for (var i in e) r.d(n, i, function(t) {
            return e[t];
        }.bind(null, i));
        return n;
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default;
        } : function() {
            return t;
        };
        return r.d(e, "a", e), e;
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e);
    }, r.p = "", r(r.s = 6);
}({
    6: function(t, e, a) {
        Component({
            options: {
                addGlobalClass: !0,
                pureDataPattern: /^_/,
                multipleSlots: !0
            },
            properties: {
                vtabs: {
                    type: Array,
                    value: []
                },
                tabBarClass: {
                    type: String,
                    value: ""
                },
                activeClass: {
                    type: String,
                    value: ""
                },
                tabBarLineColor: {
                    type: String,
                    value: "#ff0000"
                },
                tabBarInactiveTextColor: {
                    type: String,
                    value: "#000000"
                },
                tabBarActiveTextColor: {
                    type: String,
                    value: "#ff0000"
                },
                tabBarInactiveBgColor: {
                    type: String,
                    value: "#eeeeee"
                },
                tabBarActiveBgColor: {
                    type: String,
                    value: "#ffffff"
                },
                activeTab: {
                    type: Number,
                    value: 0
                },
                animation: {
                    type: Boolean,
                    value: !0
                }
            },
            data: {
                currentView: 0,
                contentScrollTop: 0,
                _heightRecords: [],
                _contentHeight: {}
            },
            observers: {
                activeTab: function(t) {
                    this.scrollTabBar(t);
                }
            },
            relations: {
                "../vtabs-content/index": {
                    type: "child",
                    linked: function(t) {
                        var e = this;
                        t.calcHeight(function(a) {
                            e.data._contentHeight[t.data.tabIndex] = a.height, e._calcHeightTimer && clearTimeout(e._calcHeightTimer), 
                            e._calcHeightTimer = setTimeout(function() {
                                e.calcHeight();
                            }, 100);
                        });
                    },
                    unlinked: function(t) {
                        delete this.data._contentHeight[t.data.tabIndex];
                    }
                }
            },
            lifetimes: {
                attached: function() {}
            },
            methods: {
                calcHeight: function() {
                    for (var t = this.data.vtabs.length, e = this.data._contentHeight, a = [], r = 0, n = 0; n < t; n++) a[n] = r + (e[n] || 0), 
                    r = a[n];
                    this.data._heightRecords = a;
                },
                scrollTabBar: function(t) {
                    var e = this.data.vtabs.length;
                    if (0 !== e) {
                        var a = t < 6 ? 0 : t - 5;
                        a >= e && (a = e - 1), this.setData({
                            currentView: a
                        });
                    }
                },
                handleTabClick: function(t) {
                    var e = this.data._heightRecords, a = t.currentTarget.dataset.index, r = e[a - 1] || 0;
                    this.triggerEvent("tabclick", {
                        index: a
                    }), this.setData({
                        activeTab: a,
                        contentScrollTop: r
                    });
                },
                handleContentScroll: function(t) {
                    var e = this.data._heightRecords;
                    if (0 !== e.length) {
                        var a = this.data.vtabs.length, r = t.detail.scrollTop, n = 0;
                        if (r >= e[0]) for (var i = 1; i < a; i++) if (r >= e[i - 1] && r < e[i]) {
                            n = i;
                            break;
                        }
                        n !== this.data.activeTab && (this.triggerEvent("change", {
                            index: n
                        }), this.setData({
                            activeTab: n
                        }));
                    }
                }
            }
        });
    }
});