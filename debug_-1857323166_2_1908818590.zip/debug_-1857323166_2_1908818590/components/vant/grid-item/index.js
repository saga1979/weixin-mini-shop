var t = require("../mixins/link"), n = require("../common/component"), i = require("../common/utils");

(0, n.VantComponent)({
    relation: {
        name: "grid",
        type: "ancestor",
        current: "grid-item"
    },
    classes: [ "content-class", "icon-class", "text-class" ],
    mixins: [ t.link ],
    props: {
        icon: String,
        iconColor: String,
        dot: Boolean,
        info: null,
        badge: null,
        text: String,
        useSlot: Boolean
    },
    data: {
        viewStyle: ""
    },
    mounted: function() {
        this.updateStyle();
    },
    methods: {
        updateStyle: function() {
            if (this.parent) {
                var t = this.parent, n = t.data, e = t.children, o = n.columnNum, c = n.border, a = n.square, r = n.gutter, s = n.clickable, l = n.center, u = n.direction, d = n.iconSize, h = "".concat(100 / o, "%"), m = [];
                if (m.push("width: ".concat(h)), a && m.push("padding-top: ".concat(h)), r) {
                    var p = (0, i.addUnit)(r);
                    m.push("padding-right: ".concat(p)), e.indexOf(this) >= o && !a && m.push("margin-top: ".concat(p));
                }
                var g = "";
                if (a && r) {
                    var S = (0, i.addUnit)(r);
                    g = "\n          right: ".concat(S, ";\n          bottom: ").concat(S, ";\n          height: auto;\n        ");
                }
                this.setData({
                    viewStyle: m.join("; "),
                    contentStyle: g,
                    center: l,
                    border: c,
                    square: a,
                    gutter: r,
                    clickable: s,
                    direction: u,
                    iconSize: d
                });
            }
        },
        onClick: function() {
            this.$emit("click"), this.jumpLink();
        }
    }
});