var e, t, a = require("../../@babel/runtime/helpers/interopRequireDefault"), s = a(require("../../@babel/runtime/helpers/defineProperty")), o = a(require("../../@babel/runtime/regenerator")), n = a(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        list: [ {
            text: "商品",
            iconPath: "/images/customer_user_home.png",
            selectedIconPath: "/images/selected_common.png"
        }, {
            text: "收藏夹",
            iconPath: "/images/customer_user_cart.png",
            selectedIconPath: "/images/selected_common.png"
        }, {
            text: "订单",
            iconPath: "/images/customer_user_history.png",
            selectedIconPath: "/images/selected_common.png"
        }, {
            text: "我",
            iconPath: "/images/customer.png",
            selectedIconPath: "/images/selected_common.png"
        } ],
        pageIndex: 0,
        goods_items: [],
        _goods_items: [],
        total_price: 0,
        grid_items: [],
        _selected_items: [],
        submitted: !0,
        nickName: "",
        avatarUrl: "",
        activeTab: 0,
        _goodsTypes: []
    },
    onLoad: (t = (0, n.default)(o.default.mark(function e(t) {
        var a, s, n = this;
        return o.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return console.debug(t), a = this, this.setData({
                    nickName: t.nickName,
                    avatarUrl: t.avatarUrl
                }), this.data._goodsTypes.push({
                    title: "推荐"
                }), console.debug(this.data), wx.showLoading({
                    title: "正在加载资源"
                }), e.next = 8, wx.cloud.callFunction({
                    name: "config",
                    data: {
                        cmd: "goodsTypes-get"
                    }
                });

              case 8:
                s = e.sent, wx.hideLoading({
                    success: function(e) {}
                }), console.debug(s.result.data), null != s.result.data && (a.data._goodsTypes = a.data._goodsTypes.concat(s.result.data)), 
                a.data._goodsTypes.push({
                    title: "未分类"
                }), a.setData({
                    goodsTypesForVtabs: a.data._goodsTypes.map(function(e) {
                        return {
                            title: e.title
                        };
                    })
                }), this.data.total_price = 0, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get-recommend"
                    }
                }).then(function(e) {
                    console.debug(e), e.result.success && n.makeShowInfos(e.result.data);
                }), null == this.data.goods_items || this.data.goods_items.length, wx.hideLoading({
                    complete: function(e) {}
                });

              case 19:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(e) {
        return t.apply(this, arguments);
    }),
    onReady: function() {
        var e = wx.createSelectorQuery();
        e.select("#mytabber").boundingClientRect();
        var t = this;
        e.exec(function(e) {
            var a = wx.getSystemInfoSync().windowHeight - e[0].height;
            t.data.viewHight != a && t.setData({
                viewHight: a
            });
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onTabChanged: function(e) {
        console.log(e), this.setData({
            pageIndex: e.detail.index
        }), 1 == e.detail.index && this.setData((0, s.default)({}, "list[".concat(e.detail.index, "].dot"), !1));
    },
    onShowDetail: function(e) {
        console.debug(e), wx.navigateTo({
            url: "../../components/myself/goods-detail/detail?_id=" + e.target.dataset.id
        });
    },
    onTapCheckbox: function(e) {
        console.debug(e);
        var t = this.data._selected_items.findIndex(function(t) {
            return t == e.target.dataset.id;
        });
        -1 == t ? this.data._selected_items.push(e.target.dataset.id) : this.data._selected_items.splice(t, 1);
        var a = e.target.dataset.index;
        this.data.goods_items[a].isChecked = !this.data.goods_items[a].isChecked;
    },
    onAddToCard: function(e) {
        var t = this;
        console.debug(this.data._selected_items), wx.cloud.callFunction({
            name: "cart-op",
            data: {
                cmd: "add",
                data: {
                    ids: this.data._selected_items
                }
            }
        }).then(function(e) {
            if (console.debug(e), e.result.success) {
                for (var a = 0; a < t.data.goods_items.length; a++) t.data.goods_items[a].isChecked && (console.debug("index:" + a + " set unchecked"), 
                t.setData((0, s.default)({}, "goods_items[" + a + "].isChecked", !1)));
                0 == e.result.data ? wx.showToast({
                    title: "已收藏"
                }) : (t.data.list[1].dot = !0, t.setData((0, s.default)({}, "list[1]", t.data.list[1])));
            }
        }).catch(function(e) {
            console.error(e);
        });
    },
    onSwitchType: (e = (0, n.default)(o.default.mark(function e(t) {
        var a, s, n;
        return o.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ((a = t.detail.index) != this.data.activeTab) {
                    e.next = 3;
                    break;
                }
                return e.abrupt("return");

              case 3:
                if (this.data.activeTab = a, s = null, 0 != a) {
                    e.next = 11;
                    break;
                }
                return e.next = 8, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get",
                        data: {
                            where: {
                                recommend: !0
                            },
                            fetched: 0
                        }
                    }
                });

              case 8:
                s = e.sent, e.next = 22;
                break;

              case 11:
                if (a != this.data._goodsTypes.length - 1) {
                    e.next = 19;
                    break;
                }
                return n = [], this.data._goodsTypes.forEach(function(e) {
                    n.push(e.title);
                }), e.next = 16, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get-notTypes",
                        data: {
                            types: n,
                            fetched: 0
                        }
                    }
                });

              case 16:
                s = e.sent, e.next = 22;
                break;

              case 19:
                return e.next = 21, wx.cloud.callFunction({
                    name: "goods-op",
                    data: {
                        cmd: "get-byTypes",
                        data: {
                            types: [ this.data._goodsTypes[a].title ],
                            fetched: 0
                        }
                    }
                });

              case 21:
                s = e.sent;

              case 22:
                console.debug(s), this.makeShowInfos(s.result.data), console.log("tabClick", a);

              case 25:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onChange: function(e) {
        var t = e.detail.index;
        console.log("change", t);
    },
    makeShowInfos: function(e) {
        this.data.grid_items = [];
        for (var t = 0; t < e.length; t++) {
            var a = {
                imgUrl: e[t].imgs[0],
                url: "../../components/myself/goods-detail/detail?_id=" + e[t]._id,
                text: e[t].name
            };
            this.data.grid_items.push(a);
        }
        this.data.goods_items = e;
        for (t = 0; t < this.data.goods_items.length; t++) this.data.goods_items[t].isChecked = !1;
        this.setData({
            goods_items: e
        });
    }
});