(0, require("../common/component").VantComponent)({
    props: {
        options: Array,
        showBorder: Boolean
    },
    methods: {
        onSelect: function(t) {
            var e = t.currentTarget.dataset.index, o = this.data.options[e];
            this.$emit("select", Object.assign(Object.assign({}, o), {
                index: e
            }));
        }
    }
});