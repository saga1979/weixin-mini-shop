Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        _id: {
            type: String,
            value: ""
        },
        editable: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        goods_item: {}
    },
    lifetimes: {
        attached: function() {
            console.debug(this.data._id);
            var t = this;
            wx.cloud.database().collection("goods").doc(this.data._id).get().then(function(e) {
                var i = e.data;
                null == i.isSelling && (i.isSelling = !0), t.setData({
                    goods_item: i
                });
            });
        },
        moved: function() {},
        detached: function() {},
        ready: function() {}
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {},
        resize: function() {}
    },
    methods: {}
});