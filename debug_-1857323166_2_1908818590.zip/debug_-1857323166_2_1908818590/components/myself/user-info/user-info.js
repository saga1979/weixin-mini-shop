Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        openid: String
    },
    data: {},
    methods: {}
});