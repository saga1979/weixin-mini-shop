var e = require("../common/component"), t = require("./utils"), i = require("./shared"), a = require("../common/validator");

(0, e.VantComponent)({
    props: Object.assign(Object.assign({
        disabled: Boolean,
        multiple: Boolean,
        uploadText: String,
        useBeforeRead: Boolean,
        afterRead: null,
        beforeRead: null,
        previewSize: {
            type: null,
            value: 80
        },
        name: {
            type: [ Number, String ],
            value: ""
        },
        accept: {
            type: String,
            value: "image"
        },
        fileList: {
            type: Array,
            value: [],
            observer: "formatFileList"
        },
        maxSize: {
            type: Number,
            value: Number.MAX_VALUE
        },
        maxCount: {
            type: Number,
            value: 100
        },
        deletable: {
            type: Boolean,
            value: !0
        },
        showUpload: {
            type: Boolean,
            value: !0
        },
        previewImage: {
            type: Boolean,
            value: !0
        },
        previewFullImage: {
            type: Boolean,
            value: !0
        },
        imageFit: {
            type: String,
            value: "scaleToFill"
        },
        uploadIcon: {
            type: String,
            value: "photograph"
        }
    }, i.chooseImageProps), i.chooseVideoProps),
    data: {
        lists: [],
        isInCount: !0
    },
    methods: {
        formatFileList: function() {
            var e = this.data, i = e.fileList, n = void 0 === i ? [] : i, s = e.maxCount, o = n.map(function(e) {
                return Object.assign(Object.assign({}, e), {
                    isImage: (0, t.isImageFile)(e),
                    isVideo: (0, t.isVideoFile)(e),
                    deletable: !(0, a.isBoolean)(e.deletable) || e.deletable
                });
            });
            this.setData({
                lists: o,
                isInCount: o.length < s
            });
        },
        getDetail: function(e) {
            return {
                name: this.data.name,
                index: null == e ? this.data.fileList.length : e
            };
        },
        startUpload: function() {
            var e = this, i = this.data, a = i.maxCount, n = i.multiple, s = i.lists;
            i.disabled || (0, t.chooseFile)(Object.assign(Object.assign({}, this.data), {
                maxCount: a - s.length
            })).then(function(t) {
                e.onBeforeRead(n ? t : t[0]);
            }).catch(function(t) {
                e.$emit("error", t);
            });
        },
        onBeforeRead: function(e) {
            var t = this, i = this.data, n = i.beforeRead, s = i.useBeforeRead, o = !0;
            "function" == typeof n && (o = n(e, this.getDetail())), s && (o = new Promise(function(i, a) {
                t.$emit("before-read", Object.assign(Object.assign({
                    file: e
                }, t.getDetail()), {
                    callback: function(e) {
                        e ? i() : a();
                    }
                }));
            })), o && ((0, a.isPromise)(o) ? o.then(function(i) {
                return t.onAfterRead(i || e);
            }) : this.onAfterRead(e));
        },
        onAfterRead: function(e) {
            var t = this.data, i = t.maxSize, a = t.afterRead;
            (Array.isArray(e) ? e.some(function(e) {
                return e.size > i;
            }) : e.size > i) ? this.$emit("oversize", Object.assign({
                file: e
            }, this.getDetail())) : ("function" == typeof a && a(e, this.getDetail()), this.$emit("after-read", Object.assign({
                file: e
            }, this.getDetail())));
        },
        deleteItem: function(e) {
            var t = e.currentTarget.dataset.index;
            this.$emit("delete", Object.assign(Object.assign({}, this.getDetail(t)), {
                file: this.data.fileList[t]
            }));
        },
        onPreviewImage: function(e) {
            if (this.data.previewFullImage) {
                var i = e.currentTarget.dataset.index, a = this.data.lists, n = a[i];
                wx.previewImage({
                    urls: a.filter(function(e) {
                        return (0, t.isImageFile)(e);
                    }).map(function(e) {
                        return e.url;
                    }),
                    current: n.url,
                    fail: function() {
                        wx.showToast({
                            title: "预览图片失败",
                            icon: "none"
                        });
                    }
                });
            }
        },
        onPreviewVideo: function(e) {
            if (this.data.previewFullImage) {
                var i = e.currentTarget.dataset.index, a = this.data.lists;
                wx.previewMedia({
                    sources: a.filter(function(e) {
                        return (0, t.isVideoFile)(e);
                    }).map(function(e) {
                        return Object.assign(Object.assign({}, e), {
                            type: "video"
                        });
                    }),
                    current: i,
                    fail: function() {
                        wx.showToast({
                            title: "预览视频失败",
                            icon: "none"
                        });
                    }
                });
            }
        },
        onClickPreview: function(e) {
            var t = e.currentTarget.dataset.index, i = this.data.lists[t];
            this.$emit("click-preview", Object.assign(Object.assign({}, i), this.getDetail(t)));
        }
    }
});