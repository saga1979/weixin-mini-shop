var e, a = require("../../@babel/runtime/helpers/interopRequireDefault"), t = a(require("../../@babel/runtime/regenerator")), n = a(require("../../@babel/runtime/helpers/asyncToGenerator"));

getApp();

Page({
    data: {
        avatarUrl: "../../images/user-unlogin.png",
        userInfo: {},
        logged: !1,
        isAdmin: !1,
        _openid: ""
    },
    onLoad: function() {
        if (!wx.cloud) return wx.redirectTo({
            url: "../chooseLib/chooseLib"
        }), void wx.showToast({
            title: "云服务不可用"
        });
        var e, a = this;
        wx.getUserInfo({
            success: (e = (0, n.default)(t.default.mark(function e(n) {
                var r, i, o, s;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return console.debug(n), r = n.userInfo, i = r.nickName, o = r.avatarUrl, a.setData({
                            logged: !0,
                            avatarUrl: o,
                            userInfo: r
                        }), e.next = 7, wx.cloud.callFunction({
                            name: "login",
                            data: {
                                userInfo: {
                                    nickName: i,
                                    avatarUrl: o
                                }
                            }
                        });

                      case 7:
                        s = e.sent, console.debug(s), a.setData({
                            _openid: s.result.data.openid
                        }), "admin" == s.result.data.user && a.setData({
                            isAdmin: !0
                        });

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e);
            })), function(a) {
                return e.apply(this, arguments);
            })
        });
    },
    onShow: function() {},
    onGetUserInfo: (e = (0, n.default)(t.default.mark(function e(a) {
        var n;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (console.log(a), n = this, this.data.logged || !a.detail.userInfo) {
                    e.next = 8;
                    break;
                }
                return this.setData({
                    logged: !0,
                    avatarUrl: a.detail.userInfo.avatarUrl,
                    userInfo: a.detail.userInfo
                }), e.next = 6, wx.cloud.callFunction({
                    name: "login",
                    data: {
                        userInfo: {
                            nickName: this.data.userInfo.nickName,
                            avatarUrl: this.data.avatarUrl
                        }
                    }
                });

              case 6:
                "admin" == e.sent.result.data.user ? n.setData({
                    isAdmin: !0
                }) : wx.redirectTo({
                    url: "../../customer/index/index?avatarUrl=" + n.data.avatarUrl + "&nickName=" + n.data.userInfo.nickName
                });

              case 8:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(a) {
        return e.apply(this, arguments);
    }),
    onSelectedCustomer: function(e) {
        wx.redirectTo({
            url: "../../customer/index/index?avatarUrl=" + this.data.avatarUrl + "&nickName=" + this.data.userInfo.nickName
        });
    },
    onSelectedAdmin: function(e) {
        wx.redirectTo({
            url: "../../admin/index/index?openid=" + this.data._openid
        });
    },
    onSystemConfig: function(e) {},
    onRequestAdmin: function(e) {
        0 != this.data._openid.length ? wx.showToast({
            title: "暂未开放此功能"
        }) : wx.showToast({
            title: "请登陆后申请",
            duration: 1500
        });
    },
    onShareAppMessage: function(e) {}
});