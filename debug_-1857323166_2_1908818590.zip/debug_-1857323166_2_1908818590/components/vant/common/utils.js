var e = require("../../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isDef = i, exports.isObj = function(e) {
    var t = (0, n.default)(e);
    return null !== e && ("object" === t || "function" === t);
}, exports.range = function(e, t, n) {
    return Math.min(Math.max(e, t), n);
}, exports.nextTick = u, exports.getSystemInfoSync = o, exports.addUnit = function(e) {
    if (!i(e)) return;
    return e = String(e), (0, r.isNumber)(e) ? "".concat(e, "px") : e;
}, exports.requestAnimationFrame = function(e) {
    if ("devtools" === o().platform) return u(e);
    return wx.createSelectorQuery().selectViewport().boundingClientRect().exec(function() {
        e();
    });
}, exports.pickExclude = function(e, t) {
    if (!(0, r.isPlainObject)(e)) return {};
    return Object.keys(e).reduce(function(n, r) {
        return t.includes(r) || (n[r] = e[r]), n;
    }, {});
}, exports.getRect = function(e) {
    var t = this;
    return new Promise(function(n) {
        wx.createSelectorQuery().in(t).select(e).boundingClientRect().exec(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            return n(e[0]);
        });
    });
}, exports.getAllRect = function(e) {
    var t = this;
    return new Promise(function(n) {
        wx.createSelectorQuery().in(t).selectAll(e).boundingClientRect().exec(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            return n(e[0]);
        });
    });
}, require("../../../@babel/runtime/helpers/Arrayincludes");

var t, n = e(require("../../../@babel/runtime/helpers/typeof")), r = require("./validator");

function i(e) {
    return null != e;
}

function u(e) {
    setTimeout(function() {
        e();
    }, 1e3 / 30);
}

function o() {
    return null == t && (t = wx.getSystemInfoSync()), t;
}