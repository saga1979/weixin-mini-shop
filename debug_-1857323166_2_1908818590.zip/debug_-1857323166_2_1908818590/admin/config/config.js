Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        openid: String,
        height: String
    },
    data: {
        functions: [ {
            title: "类别",
            url: "../goods-types-manager/goods-types-manager"
        }, {
            title: "活动",
            url: "../discount-manager/discount-manager"
        }, {
            title: "推荐",
            url: "../recommend/recommend"
        } ]
    },
    lifetimes: {
        attached: function() {},
        ready: function() {},
        moved: function() {},
        detached: function() {}
    },
    methods: {
        onClickFunction: function(t) {
            console.debug(t), wx.navigateTo({
                url: this.data.functions[t.target.dataset.index].url
            });
        }
    }
});