var e, t, a, o, n, s = require("../../@babel/runtime/helpers/interopRequireDefault"), d = s(require("../../@babel/runtime/helpers/defineProperty")), r = s(require("../../@babel/runtime/regenerator")), i = s(require("../../@babel/runtime/helpers/asyncToGenerator")), u = (getApp(), 
require("miniprogram-recycle-view")), c = function(e) {
    return e / 750 * wx.getSystemInfoSync().windowWidth;
}, l = null;

Component({
    options: {
        styleIsolation: "apply-shared"
    },
    properties: {
        nickName: {
            type: String,
            value: ""
        },
        avatarUrl: String
    },
    data: {
        ordersToShow: [],
        _curTabIndex: 0,
        stagesCount: [ 0, 0, 0, 0, 0 ]
    },
    lifetimes: {
        attached: (n = (0, i.default)(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    console.log("attached"), wx.showLoading({
                        title: "正在请求数据"
                    }), setTimeout(function() {
                        wx.hideLoading();
                    }, 1500), l = u({
                        id: "recycleId",
                        dataKey: "recycleList",
                        page: this,
                        itemSize: this.itemSizeFunc,
                        useInPage: !1
                    }), this.getOrderInfos([ 0 ], !0, {
                        begin: 1,
                        end: 100
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return n.apply(this, arguments);
        }),
        moved: function() {},
        detached: function() {
            console.log("detached");
        },
        ready: function() {}
    },
    pageLifetimes: {
        show: function() {
            console.log("show");
        },
        hide: function() {},
        resize: function() {}
    },
    methods: {
        getOrderInfos: (o = (0, i.default)(r.default.mark(function e(t, a, o) {
            var n, s, d, i;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = this, console.debug(a), e.next = 4, wx.cloud.callFunction({
                        name: "orders-op",
                        data: {
                            cmd: "get",
                            stages: t,
                            range: {
                                begin: o.begin,
                                end: o.end
                            },
                            statistics: a
                        }
                    });

                  case 4:
                    if (s = e.sent, console.debug(s.result), a) {
                        for (a = s.result.statistics, d = 0; d < a.length; d++) n.data.stagesCount[a[d]._id] = a[d].num;
                        console.debug(n.data.stagesCount), n.setData({
                            stagesCount: n.data.stagesCount
                        });
                    }
                    for (n.data.ordersToShow = [], d = 0; d < s.result.data.length; d++) i = s.result.data[d], 
                    n.data.ordersToShow.push(i);
                    n.setData({
                        ordersToShow: s.result.data
                    }), l.splice(0, l.getList().length), l.append(n.data.ordersToShow), console.debug(n.data.ordersToShow);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e, t, a) {
            return o.apply(this, arguments);
        }),
        itemSizeFunc: function(e, t) {
            return console.debug(e, t), {
                width: c(750),
                height: c(350)
            };
        },
        onTabClick: function(e) {
            var t = e.detail.index;
            this.data._curTabIndex != t && (this.data._curTabIndex = t, t = 5 == t ? [ 0, 1, 2, 3, 4 ] : [ t ], 
            this.getOrderInfos(t, !1, {
                begin: 1,
                end: 100
            }));
        },
        onPreviewGoods: function(e) {
            console.debug(e);
            var t = e.target.dataset.id;
            wx.navigateTo({
                url: "../../components/myself/goods-detail/detail?_id=" + t
            });
        },
        onOrderCancel: (a = (0, i.default)(r.default.mark(function e(t) {
            var a, o;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.debug(t), e.next = 3, wx.cloud.callFunction({
                        name: "orders-op",
                        data: {
                            cmd: "cancel",
                            ids: [ t.target.dataset.id ]
                        }
                    });

                  case 3:
                    a = e.sent, console.debug(a), 0 != a.result.updated && (o = this.data.ordersToShow.findIndex(function(e) {
                        return e._id == t.target.dataset.id;
                    }), console.debug("find index:", o), -1 != o && (this.data.ordersToShow[o].stage.value = 4, 
                    this.data.ordersToShow.splice(o, 1), this.setData((0, d.default)({
                        ordersToShow: this.data.ordersToShow
                    }, "stagesCount[".concat(this.data._curTabIndex, "]"), --this.data.stagesCount[this.data._curTabIndex])), 
                    l.splice(0, l.getList().length), l.append(this.data.ordersToShow), console.debug(this.data.ordersToShow)));

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return a.apply(this, arguments);
        }),
        onOrderDelete: (t = (0, i.default)(r.default.mark(function e(t) {
            var a, o;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.debug(t), e.next = 3, wx.cloud.callFunction({
                        name: "orders-op",
                        data: {
                            cmd: "delete",
                            ids: [ t.target.dataset.id ]
                        }
                    });

                  case 3:
                    a = e.sent, console.debug(a), 0 != a.result.updated && (o = this.data.ordersToShow.findIndex(function(e) {
                        return e._id == t.target.dataset.id;
                    }), console.debug("find index:", o), -1 != o && (this.data.ordersToShow[o].stage.value = 5, 
                    this.data.ordersToShow.splice(o, 1), this.setData((0, d.default)({
                        ordersToShow: this.data.ordersToShow
                    }, "stagesCount[".concat(this.data._curTabIndex, "]"), --this.data.stagesCount[this.data._curTabIndex])), 
                    l.splice(0, l.getList().length), l.append(this.data.ordersToShow), console.debug(this.data.ordersToShow)));

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return t.apply(this, arguments);
        }),
        onOrderComplete: (e = (0, i.default)(r.default.mark(function e(t) {
            var a, o;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return console.debug(t), e.next = 3, wx.cloud.callFunction({
                        name: "orders-op",
                        data: {
                            cmd: "update-stage",
                            data: {
                                id: t.target.dataset.id,
                                stage: {
                                    title: "已完成",
                                    value: 3
                                },
                                timeline: {
                                    status: "客户已确认收货"
                                }
                            }
                        }
                    });

                  case 3:
                    a = e.sent, console.debug(a), a.result.success && (o = this.data.ordersToShow.findIndex(function(e) {
                        return e._id == t.target.dataset.id;
                    }), console.debug("find index:", o), -1 != o && (this.data.ordersToShow[o].stage.value = 3, 
                    this.data.ordersToShow.splice(o, 1), this.setData((0, d.default)({
                        ordersToShow: this.data.ordersToShow
                    }, "stagesCount[".concat(this.data._curTabIndex, "]"), --this.data.stagesCount[this.data._curTabIndex])), 
                    console.debug(this.data), l.splice(0, l.getList().length), l.append(this.data.ordersToShow)));

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(t) {
            return e.apply(this, arguments);
        }),
        onShowDetail: function(e) {
            console.debug(e), wx.navigateTo({
                url: "../../components/myself/order-detail/order-detail?id=" + e.target.dataset.id
            });
        },
        onShowFlowInfo: function(e) {},
        onContact: function(e) {
            console.debug(e), wx.navigateTo({
                url: "../../myself/order-detail/order-detail?id=" + e.detail.query.id
            });
        }
    }
});